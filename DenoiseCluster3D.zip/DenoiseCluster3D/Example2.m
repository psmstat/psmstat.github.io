
n1=32; n2=32; n3=32;
img3 = zeros(n1,n2,n3);
img3(5:22,11:22,11:22) = 2;
for i=1:n1; for j=1:n2; for k=1:n3;
if (((i-16)/n1)^2+((j-16)/n2)^2+((k-16)/n3)^2<=0.45^2 & j>=20)
img3(i,j,k)=3.0;
end;
if (i > j)
img3(i,j,k) = 1; end;
if (((j-10)/n2)^2 <= ((i-22)/n1)^2 + ((k-16)/n3)^2 & i>=12)
img3(i,j,k) = 3;
end;end;end;end;
noisyimg = img3 + 0.15*randn(n1,n2,n3);
imagesc(squeeze(noisyimg(:,:,n3/2)));colormap(gray);

img3_gr1=imfilter(img3, permute(fspecial('sobel'),[1,2,3]),'replicate');
img3_gr2=imfilter(img3, permute(fspecial('sobel'),[2,3,1]),'replicate');
img3_gr3=imfilter(img3, permute(fspecial('sobel'),[3,1,2]),'replicate');

img3_gr=sqrt(img3_gr1.^2+img3_gr2.^2+img3_gr3.^2);

s=0;
for i=2:n1-1; for j=2:n2-1; for k=2:n3-1;
if (abs(img3_gr1(i,j,k))>=abs(img3_gr2(i,j,k)) & abs(img3_gr1(i,j,k))>=abs(img3_gr3(i,j,k)))
    s=s+abs(img3(i+1,j,k)-img3(i-1,j,k));end;
if (abs(img3_gr2(i,j,k))>=abs(img3_gr1(i,j,k)) & abs(img3_gr2(i,j,k))>=abs(img3_gr3(i,j,k)))
    s=s+abs(img3(i,j+1,k)-img3(i,j-1,k));end;
if (abs(img3_gr3(i,j,k))>=abs(img3_gr1(i,j,k)) & abs(img3_gr3(i,j,k))>=abs(img3_gr2(i,j,k)))
    s=s+abs(img3(i,j,k+1)-img3(i,j,k-1));end;
end;end;end;
s=s/((n1-2)*(n2-2)*(n3-2));


denoised_all=zeros(n1,n2,n3);
t1=tic;
iteration=2;
sigma=0.10;
mseiter=zeros(iteration,1); jsiter=zeros(iteration,1); ssimiter=zeros(iteration,1);
for iter=1:iteration
iter
noisyimage=img3+randn(size(img3))*sigma;
denoised = DenoiseCluster3D(noisyimage,5.0,15.0,6);

mset = (denoised-img3).^2;
mse = mean(mset(:));
mseiter(iter)=mse;

ss=0;
for i=2:n1-1; for j=2:n2-1; for k=2:n3-1;
if (abs(img3_gr1(i,j,k))>=abs(img3_gr2(i,j,k)) & abs(img3_gr1(i,j,k))>=abs(img3_gr3(i,j,k)))
    ss=ss+abs(denoised(i+1,j,k)-denoised(i-1,j,k));end;
if (abs(img3_gr2(i,j,k))>=abs(img3_gr1(i,j,k)) & abs(img3_gr2(i,j,k))>=abs(img3_gr3(i,j,k)))
    ss=ss+abs(denoised(i,j+1,k)-denoised(i,j-1,k));end;
if (abs(img3_gr3(i,j,k))>=abs(img3_gr1(i,j,k)) & abs(img3_gr3(i,j,k))>=abs(img3_gr2(i,j,k)))
    ss=ss+abs(denoised(i,j,k+1)-denoised(i,j,k-1));end;
end;end;end;
ss=ss/((n1-2)*(n2-2)*(n3-2));
js=abs(s-ss)/s;
jsiter(iter)=js;

noise_est=noisyimage-denoised;
ssimiter(iter)=ssim(denoised,noise_est);

end
sprintf('-------------------------------')
mean(mseiter) % Mean MSE
std(mseiter) % SD MSE
sprintf('-------------------------------')
mean(jsiter) % Mean EP
std(jsiter)  % SD EP
sprintf('-------------------------------')
mean(ssimiter) % Mean SSIM
sprintf('-------------------------------')
figure(1); imagesc(squeeze(noisyimg(:,:,n3/2)));colormap(gray);
figure(2);imagesc(squeeze(denoised(:,:,n3/2)));colormap(gray);
