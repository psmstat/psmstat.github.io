
 n1=32; n2=32; n3=32;
 img3 = zeros(n1,n2,n3);
 img3(5:22,11:22,11:22) = 2;
 for i=1:n1; for j=1:n2; for k=1:n3;
 if (((i-16)/n1)^2+((j-16)/n2)^2+((k-16)/n3)^2<=0.45^2 & j>=20)
 img3(i,j,k)=3.0;
 end;
 if (i > j)
 img3(i,j,k) = 1; end;
 if (((j-10)/n2)^2 <= ((i-22)/n1)^2 + ((k-16)/n3)^2 & i>=12)
 img3(i,j,k) = 3;
 end;end;end;end;
 noisyimg = img3 + 0.10*randn(n1,n2,n3);

 denoised = DenoiseCluster3D(noisyimage,5.0,15.0,6);

 figure(1); imagesc(squeeze(noisyimg(:,:,n3/2)));colormap(gray);
 figure(2); imagesc(squeeze(denoised(:,:,n3/2)));colormap(gray);
 