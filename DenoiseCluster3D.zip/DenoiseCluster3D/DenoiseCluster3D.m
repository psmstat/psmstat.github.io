function denoised = DenoiseCluster3D(noisyimage,nhmax,smp,nbins)
%
% Test example: Create a simulated image, add noise, and denoise using
% DenoiseCluster3D
%
% n1=32; n2=32; n3=32;
% img3 = zeros(n1,n2,n3);
% img3(5:22,11:22,11:22) = 2;
% for i=1:n1; for j=1:n2; for k=1:n3;
% if (((i-16)/n1)^2+((j-16)/n2)^2+((k-16)/n3)^2<=0.45^2 & j>=20)
% img3(i,j,k)=3.0;
% end;
% if (i > j)
% img3(i,j,k) = 1; end;
% if (((j-10)/n2)^2 <= ((i-22)/n1)^2 + ((k-16)/n3)^2 & i>=12)
% img3(i,j,k) = 3;
% end;end;end;end;
% noisyimg = img3 + 0.10*randn(n1,n2,n3);
%
% denoised = DenoiseCluster3D(noisyimage,5.0,15.0,6);
%
% figure(1); imagesc(squeeze(noisyimg(:,:,n3/2)));colormap(gray);
% figure(2); imagesc(squeeze(denoised(:,:,n3/2)));colormap(gray);



[n1 n2 n3]=size(noisyimage); pw=ceil(nhmax)+2;
pnimg = padarray(noisyimage,[pw pw pw],'symmetric');
nhpilotsig=1.0; nhpilotcl=3.0;

ncl=zeros(2*pw+n1,2*pw+n2,2*pw+n3);
est=zeros(2*pw+n1,2*pw+n2,2*pw+n3);
est_lck=zeros(2*pw+n1,2*pw+n2,2*pw+n3);

cnhps=ceil(nhpilotsig);
sumtemp1=0;
for i=pw+1:pw+n1; for j=pw+1:pw+n2; for k=pw+1:pw+n3;
  c = 0;
  for i1=i-cnhps:i+cnhps; for j1=j-cnhps:j+cnhps; for k1=k-cnhps:k+cnhps;
    if ((i1-i)^2+(j1-j)^2+(k1-k)^2 <= nhpilotsig^2)
    c=c+1; t(c)=pnimg(i1,j1,k1); tloc1(c)=i1; tloc2(c)=j1; tloc3(c)=k1;
    end
  end; end; end;
  est_lck(i,j,k) = lck3([tloc1' tloc2' tloc3'],t',[i;j;k],nhpilotsig);
  sumtemp1 = sumtemp1 + (pnimg(i,j,k)-est_lck(i,j,k))^2;
end; end; end;
sigmahat = sqrt(sumtemp1/(n1*n2*n3));

spnd = snhood(nhpilotcl);
cnhpc = ceil(nhpilotcl);

for i=1+pw:n1+pw; for j=1+pw:n2+pw; for k=1+pw:n3+pw
locimg = pnimg(i-cnhpc:i+cnhpc,j-cnhpc:j+cnhpc,k-cnhpc:k+cnhpc);
tt=locimg(spnd);
[x y] = hist(tt, nbins);

cutoffs = [];
for ii=2:nbins-1
    if (x(ii-1) >= x(ii) && x(ii+1) >= x(ii) && ~(x(ii-1)==x(ii) && x(ii)==x(ii+1)))
        cutoffs=[cutoffs y(ii)];
    end
end
cutoffs=[min(tt) cutoffs max(tt)];

ncl(i,j,k) = length(cutoffs)-1;
end; end; end;


for i=1+pw:n1+pw; for j=1+pw:n2+pw; for k=1+pw:n3+pw
            nh = max(1.0,nhmax*exp(-(ncl(i,j,k)-1)/nhmax));
           cnh = ceil(nh);
           spnd = snhood(cnh);
           locimg = pnimg(i-cnh:i+cnh,j-cnh:j+cnh,k-cnh:k+cnh);
           tt=locimg(spnd);
[x y] = hist(tt, nbins); x;
cutoffs = [];
for ii=2:nbins-1
    if (x(ii-1) >= x(ii) && x(ii+1) >= x(ii) && ~(x(ii-1)==x(ii) && x(ii)==x(ii+1)))
        cutoffs=[cutoffs y(ii)];
    end
end
if (min(tt) < max(tt)) cutoffs=[min(tt) cutoffs max(tt)]; end;

if (isempty(cutoffs) == 1) cutoffs=[-Inf,Inf]; end;



grpos = sum(cutoffs < pnimg(i,j,k));
if (grpos == 0) t1 = cutoffs(1); t2 = cutoffs(2);
else if (grpos == length(cutoffs)) t1 = cutoffs(grpos); t2 = Inf;
    else t1 = cutoffs(grpos); t2 = cutoffs(grpos+1);
    end; end;
grapt = tt((tt <= t2 ) & (tt >= t1));

grmin = min(grapt); grmax = max(grapt); grstd = std(grapt);
h = smp*exp(-(grstd/sigmahat)^1);
denom = 2*(grstd^2)*h;
  
if (grstd == 0) est(i,j,k) = mean(grapt);
else

  s = 0; wt = 0;
           
  tempv1 = [pnimg(i,j,k) pnimg(i-1,j,k) pnimg(i+1,j,k) pnimg(i,j-1,k) pnimg(i,j+1,k) pnimg(i,j,k-1) pnimg(i,j,k+1)];
  for i1=i-cnh:i+cnh;
      for j1=j-cnh:j+cnh;
          for k1=k-cnh:k+cnh;
              if ((i1-i)^2+(j1-j)^2+(k1-k)^2 <= nh^2 && pnimg(i1,j1,k1) >= grmin && pnimg(i1,j1,k1) <= grmax)
              tempv2 = [pnimg(i1,j1,k1) pnimg(i1-1,j1,k1) pnimg(i1+1,j1,k1) pnimg(i1,j1-1,k1) pnimg(i1,j1+1,k1) ...
                        pnimg(i1,j1,k1-1) pnimg(i1,j1,k1+1)];
              w = exp(-((sum(tempv1 - tempv2).^2)/length(tempv1))/denom);
              if (sum((tempv1 - tempv2).^2) == 0) w=1; end;
              wt = wt + w;
              s = s + w*pnimg(i1,j1,k1);
              end;
          end;
      end;
  end;
  est(i,j,k) = s/wt;
  
end;

            
end;end;end;

denoised = est(1+pw:n1+pw,1+pw:n2+pw,1+pw:n3+pw);

