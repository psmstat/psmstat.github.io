##==================   Last Updated on 17 February, 2024   =============== ##

##       R-Code (Image Comparison Based On Local Pixel Clustering)         ##


## The following code is useful to reproduce Table 2 with noise level 0.08 
## To generate other cells, change the noise level accordingly.            

#======= Required Library =========#
library(magic)
library(pracma)
library(jpeg)
library(DRIP)
library(mcclust)

# Required Library for Parallel Computation #
library(foreach)
library(doParallel)


#======= True Image(Null Image) =======#

x=matrix(0,nrow=128,ncol=128)
for(i in 1:128){
  for(j in 1:128){
    if(((i-64)^2+(j-64)^2<256)){
      x[i,j]=1
    }
  }
}
image(x,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))

#====== Scratch =========#
m1=matrix(0,nrow=128,ncol=128)
for(i in 1:128){
  for(j in 1:128){
    if(((i-64)^2+(j-64)^2<256)){
      m1[i,j]=1
    }
  }
}
for(k in 62:64){
  for(l in 62:64){
    if(k==l && l==k)
      m1[k,l]=0.4
  }
}
image(m1,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))

#====== Zooming ======#
m2=matrix(0,nrow=128,ncol=128)
for(i in 1:128){
  for(j in 1:128){
    if(((i/16.2-64/16.2)^2+(j/16.2-64/16.2)^2<1)){
      m2[i,j]=1
    }
  }
}
image(m2,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))

#===== Translation ========#
m3=matrix(0,nrow=128,ncol=128)
for(i in 1:128){
  for(j in 1:128){
    if(((i-66)^2+(j-66)^2<256)){
      m3[i,j]=1
    }
  }
}
image(m3,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))

#========== Circular Fault =========# 
m4=matrix(0,nrow=128,ncol=128)
for(i in 1:128){
  for(j in 1:128){
    if(((i-64)^2+(j-64)^2<256)){
      m4[i,j]=1
    }
  }
}

for(k in 1:128){
  for(l in 1:128){
    if(((k-64)^2+(l-64)^2<(2*0.7)^2))
      m4[k,l]=0.3
  }
}
image(m4,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))

#====== Smooth Change in The Background ===========#
m=matrix(0,nrow=128,ncol=128)
for(i in 1:128){
  for(j in 1:128){
    if(((i-64)^2+(j-64)^2<256)){
      m[i,j]=1
    }else{
      m[i,j]=0.1*sin(0.1*(i+j))
    }
  }
}
image(m,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))

#=========================================================================================#

## Residual from the combined samples ##
set.seed(2023)
Im_1=x+matrix(rnorm(nrow(x)*ncol(x),0,0.08),nrow=nrow(x),ncol=ncol(x)) # Observed Image 1
Im_2=x+matrix(rnorm(nrow(x)*ncol(x),0,0.08),nrow=nrow(x),ncol=ncol(x)) # Observed Image 2
image(Im_1,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))
est_Im_1=surfaceCluster(Im_1,3,0.999,plot=F)
est_Im_2=surfaceCluster(Im_2,3,0.999,plot=F)
residual=Im_1-((est_Im_1$estImg+est_Im_2$estImg)/2)
image((est_Im_1$estImg+est_Im_2$estImg)/2,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))
sigma_hat=est_Im_1$sigma

#==========================================================================================#


### How many elements in a circular neighborhood? ###
h=3
g=expand.grid(-ceiling(h):ceiling(h),-ceiling(h):ceiling(h))
g$d2 = sqrt ((g$Var1)^2 + (g$Var2)^2)
n_cir = length(g$d2[g$d2<=h])


### Function to extract y for each (i,j)^th pixel of image ###
extract_y=function(A,i,j){
  p=10 #padded size
  m_1=apad(A,c(p,p),method="mirror")
  m_2=rbind(m_1[p:1,],m_1)
  M=cbind(m_2[,p:1],m_2)
  h=3
  i1=i+p
  j1=j+p
  g = expand.grid((i1-ceiling(h)):(i1+ceiling(h)),(j1-ceiling(h)):(j1+ceiling(h)))
  g$d2 = sqrt ((g$Var1-i1)^2 + (g$Var2-j1)^2)
  g$inside = g$d2<=h
  y=M[as.matrix(g[g$inside,c("Var1","Var2")])]
  return(y)
}

#===============================================================================#

### Function for optimal value of s ###

opt_s=function(y){
  T_s=c()
  length(y)
  minimum=min(y)
  maximum=max(y)
  v=seq(minimum,maximum,0.0025)
  for( k in 1:length(v)){
    y_1=y[y>v[k]]
    y_2=y[y<=v[k]]
    T_s[k]=((length(y_1)*(mean(y_1)-mean(y))^2)+(length(y_2)*(mean(y_2)-mean(y))^2))/(sum((y_1-mean(y_1))^2)+sum((y_2-mean(y_2))^2))
  }
  return(v[which.max(T_s)])
}

#================================================================================#
### function to calculate the VI based test statistic ####
H1=function(x){
  library(DRIP)
  G=array(0,dim=c(1,n_cir,(nrow(x))^2))
  k=0
  for(i in 1:nrow(x)){
    for(j in 1:ncol(x)){
      k=k+1
      G[,,k]=extract_y(x,i,j)
      
    }
  }
  cut_off=apply(G, 3, opt_s)
  
  sigma_hat = JPLLK_surface(x,3, plot = FALSE)$sigma
  G_cluster=array(0,dim=c(1,n_cir,(nrow(x))^2))
  for(k in 1:(nrow(x))^2){
    if(std(c(G[,,k]))<1.5*sigma_hat){    #choose suitable tuning parameter (here kappa=1.5)
      G_cluster[,,k]=rep(0,n_cir)
    }else{
      G_cluster[,,k]=ifelse(G[,,k]> cut_off[k],1,0)
    }
    
  }
  return(G_cluster)
}
#==========================================================================================#


#setup parallel backend to use many processors
cores=detectCores()
cl <- makeCluster(max(1,cores[1]-2)) #not to overload your computer
registerDoParallel(cl)

set.seed(2022)
n=500           #No of Bootstrap sample, Remark: Each iteration takes approximately 2-2.5 mins.
M1=array(0,dim=c(nrow(x),ncol(x),n))
M2=array(0,dim=c(nrow(x),ncol(x),n))

for(i in 1:n){
  M1[,,i]=(est_Im_1$estImg+est_Im_2$estImg)/2+matrix(sample(residual,nrow(x)*ncol(x),replace = T),nrow=nrow(x),ncol=ncol(x))
  M2[,,i]=(est_Im_1$estImg+est_Im_2$estImg)/2+matrix(sample(residual,nrow(x)*ncol(x),replace = T),nrow=nrow(x),ncol=ncol(x))
  
}

T_VI=foreach(i = 1:n,.combine = c)%dopar%{
  library(magic)
  library(pracma)
  library(jpeg)
  library(DRIP)
  library(mcclust)
  MMM1=H1(M1[,,i])
  MMM2=H1(M2[,,i])
  s=0
  mm=c()
  for(k  in 1:(nrow(x))^2){
    s=s+vi.dist(MMM1[,,k],MMM2[,,k])
  }
  s
  
}

length(T_VI)
hist(T_VI)
quan_VI=quantile(T_VI,0.95)

#=== Calculate Empirical Size ===========#
set.seed(2023)
M_a=array(0,dim=c(nrow(x),ncol(x),n))
for(i in 1:n){
  M_a[,,i]=x+matrix(rnorm(nrow(x)*ncol(x),0,sigma_hat),nrow=nrow(x),ncol=ncol(x))
}

###   To find empirical distribution   ###
T_VI_1=foreach(i = 1:n,.combine = c)%dopar%{
  library(magic)
  library(pracma)
  library(jpeg)
  library(DRIP)
  library(mcclust)
  MMM_a=H1(M_a[,,i])
  MMM1=H1(M1[,,i])
  s=0
  for(k  in 1:(nrow(x))^2){
    s=s+vi.dist(MMM_a[,,k],MMM1[,,k])
  }
  s
}

emp_power_10=sum(ifelse(T_VI_1>quan_VI,1,0))/n #empirical size

#============= Calculate Power with Alternative image (Scratch) =====#

set.seed(2023)
M_a=array(0,dim=c(nrow(x),ncol(x),n))
for(i in 1:n){
  M_a[,,i]=m1+matrix(rnorm(nrow(x)*ncol(x),0,0.08),nrow=nrow(x),ncol=ncol(x))
}



T_VI_1=foreach(i = 1:n,.combine = c)%dopar%{
  library(magic)
  library(pracma)
  library(jpeg)
  library(DRIP)
  library(mcclust)
  MMM_a=H1(M_a[,,i])
  MMM1=H1(M1[,,i])
  s=0
  for(k  in 1:(nrow(x))^2){
    s=s+vi.dist(MMM_a[,,k],MMM1[,,k])
  }
  s
}

emp_power_11=sum(ifelse(T_VI_1>quan_VI,1,0))/n
# Table 2 of the manuscript (Noise level- 0.08, image type- Scratch)

#============= Calculate Power with Alternative image (Zooming) =====#
set.seed(2023)
M_a=array(0,dim=c(nrow(x),ncol(x),n))
for(i in 1:n){
  M_a[,,i]=m2+matrix(rnorm(nrow(x)*ncol(x),0,0.08),nrow=nrow(x),ncol=ncol(x))
}


T_VI_1=foreach(i = 1:n,.combine = c)%dopar%{
  library(magic)
  library(pracma)
  library(jpeg)
  library(DRIP)
  library(mcclust)
  MMM_a=H1(M_a[,,i])
  MMM1=H1(M1[,,i])
  s=0
  for(k  in 1:(nrow(x))^2){
    s=s+vi.dist(MMM_a[,,k],MMM1[,,k])
  }
  s
}

emp_power_12=sum(ifelse(T_VI_1>quan_VI,1,0))/n
# Table 2 of the manuscript (Noise level- 0.08, image type- Zooming)


#============= Calculate Power with Alternative image (Translation) =====#

set.seed(2023)
M_a=array(0,dim=c(nrow(x),ncol(x),n))
for(i in 1:n){
  M_a[,,i]=m3+matrix(rnorm(nrow(x)*ncol(x),0,0.08),nrow=nrow(x),ncol=ncol(x))
}



T_VI_1=foreach(i = 1:n,.combine = c)%dopar%{
  library(magic)
  library(pracma)
  library(jpeg)
  library(DRIP)
  library(mcclust)
  MMM_a=H1(M_a[,,i])
  MMM1=H1(M1[,,i])
  s=0
  for(k  in 1:(nrow(x))^2){
    s=s+vi.dist(MMM_a[,,k],MMM1[,,k])
  }
  s
}

emp_power_13=sum(ifelse(T_VI_1>quan_VI,1,0))/n
# Table 2 of the manuscript (Noise level- 0.08, image type- Translation)


#============= Calculate Power with Alternative image (Circular Fault) =====#
set.seed(2023)
M_a=array(0,dim=c(nrow(x),ncol(x),n))
for(i in 1:n){
  M_a[,,i]=m4+matrix(rnorm(nrow(x)*ncol(x),0,0.08),nrow=nrow(x),ncol=ncol(x))
}



T_VI_1=foreach(i = 1:n,.combine = c)%dopar%{
  library(magic)
  library(pracma)
  library(jpeg)
  library(DRIP)
  library(mcclust)
  MMM_a=H1(M_a[,,i])
  MMM1=H1(M1[,,i])
  s=0
  for(k  in 1:(nrow(x))^2){
    s=s+vi.dist(MMM_a[,,k],MMM1[,,k])
  }
  s
}

emp_power_14=sum(ifelse(T_VI_1>quan_VI,1,0))/n
# Table 2 of the manuscript (Noise level- 0.08, image type- Circular Fault)

# Remark: Each iteration takes approximately 2-2.5 mins.