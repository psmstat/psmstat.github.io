##====== Data driven selection of tuning parameter =====##


#== Required Library ==#
library(magic)
library(pracma) 
library(jpeg)
library(DRIP)
library(mcclust)

#== True image ==#
x=matrix(0,nrow=128,ncol=128)
for(i in 1:128){
  for(j in 1:128){
    if(((i-64)^2+(j-64)^2<256)){
      x[i,j]=1
    }
  }
}
image(x,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))

#== How many element in a circular neighborhood? ==#
h=3
g=expand.grid(-ceiling(h):ceiling(h),-ceiling(h):ceiling(h))
g$d2 = sqrt ((g$Var1)^2 + (g$Var2)^2)
n_cir = length(g$d2[g$d2<=h])


#== Function to extract y for each (i,j)^th pixel of image ==#
extract_y=function(A,i,j){
  p=10 #padded size
  m_1=apad(A,c(p,p),method="mirror")
  m_2=rbind(m_1[p:1,],m_1)
  M=cbind(m_2[,p:1],m_2)
  h=3
  i1=i+p
  j1=j+p
  g = expand.grid((i1-ceiling(h)):(i1+ceiling(h)),(j1-ceiling(h)):(j1+ceiling(h)))
  g$d2 = sqrt ((g$Var1-i1)^2 + (g$Var2-j1)^2)
  g$inside = g$d2<=h
  y=M[as.matrix(g[g$inside,c("Var1","Var2")])]
  return(y)
}



#== Function for optimal value of s ==#
opt_s=function(y){
  T_s=c()
  length(y)
  minimum=min(y)
  maximum=max(y)
  v=seq(minimum,maximum,0.0025)
  for( k in 1:length(v)){
    y_1=y[y>v[k]]
    y_2=y[y<=v[k]]
    T_s[k]=((length(y_1)*(mean(y_1)-mean(y))^2)+(length(y_2)*(mean(y_2)-mean(y))^2))/(sum((y_1-mean(y_1))^2)+sum((y_2-mean(y_2))^2))
  }
  return(v[which.max(T_s)])
}

#== Function for calculating the VI based test statistic ==#
# x = image matrix
# kap= value of the tuning parameter

H1=function(x,kap){
  library(DRIP)
  G=array(0,dim=c(1,n_cir,(nrow(x))^2))
  k=0
  for(i in 1:nrow(x)){
    for(j in 1:ncol(x)){
      k=k+1
      G[,,k]=extract_y(x,i,j)
      
    }
  }
  cut_off=apply(G, 3, opt_s)
  
  sigma_hat = JPLLK_surface(x,3, plot = FALSE)$sigma
  G_cluster=array(0,dim=c(1,n_cir,(nrow(x))^2))
  for(k in 1:(nrow(x))^2){
    if(std(c(G[,,k]))<kap*sigma_hat){    
      G_cluster[,,k]=rep(0,length(k))
    }else{
      G_cluster[,,k]=ifelse(G[,,k]> cut_off[k],1,0)
    }
    
  }
  return(G_cluster)
}

kap=seq(1,8,0.1) # different values  of tuning parameters
VI_DIST=matrix(0,nrow=3,ncol=length(kap)) # to store the VI-based distance for different values of tuning parameters
noise_level=c(0.03,0.05,0.08) # different noise levels 

for(u in 1:3){
  Im_1=x+matrix(rnorm(nrow(x)*ncol(x),0,noise_level[u]),nrow=nrow(x),ncol=ncol(x)) # Observed Image 1
  image(Im_1,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))
  est_Im_1=surfaceCluster(Im_1,3,0.999,plot=T)
  residual=Im_1-est_Im_1$estImg
  image(est_Im_1$estImg,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))
  sigma_hat=est_Im_1$sigma
  sigma_hat = JPLLK_surface(Im_1,3, plot = FALSE)$sigma
  
  
  # Required Library for Parallel Computation #
  library(foreach)
  library(doParallel)
  
  #setup parallel backend to use many processors
  cores=detectCores()
  cl <- makeCluster(cores[1]-2) #not to overload your computer
  registerDoParallel(cl)
  
  set.seed(2022)
  n=20
  M=array(0,dim=c(nrow(x),ncol(x),n))
  MM=array(0,dim=c(1,n_cir,(nrow(x))^2))
  
  for(i in 1:n){
    M[,,i]=est_Im_1$estImg+matrix(sample(residual,nrow(x)*ncol(x),replace = T),nrow=nrow(x),ncol=ncol(x))
  }
 
  for(v in 1:length(kap)){
    MM=H1(est_Im_1$estImg,kap[v])
    T_VI=foreach(i = 1:n,.combine = c)%dopar%{
      library(magic)
      library(pracma) 
      library(jpeg)
      library(DRIP)
      library(mcclust)
      MMM=H1(M[,,i],kap[v])
      s=0
      mm=c()
      for(k  in 1:(nrow(x))^2){
        mm[k]=vi.dist(MMM[,,k],MM[,,k])
        s=s+vi.dist(MMM[,,k],MM[,,k])
      }
      s
    }
    
    VI_DIST[u,v]=mean(T_VI)
  }
}

#== Required library for gg-plot ==#
library(ggplot2)
library(gridExtra)
data1=data.frame(VI_DIST[1,][seq(1,71,2)]/128^2,kap[seq(1,71,2)])
data2=data.frame(VI_DIST[2,][seq(1,71,2)]/128^2,kap[seq(1,71,2)])
data3=data.frame(VI_DIST[3,][seq(1,71,2)]/128^2,kap[seq(1,71,2)])
plot1<- ggplot(data1,aes(x=kap[seq(1,71,2)], y= data1$VI_DIST.1....seq.1..71..2...128.2))+geom_line(lwd=0.5) +xlab(expression("  " ~ kappa)) +geom_point(size=1) +xlim(1,8) +ylim(0,0.05)+ylab("VI")+ggtitle(expression("                " ~ sigma == 0.03))
plot2<- ggplot(data2,aes(x=kap[seq(1,71,2)], y= data2$VI_DIST.2....seq.1..71..2...128.2))+geom_line(lwd=0.5) +xlab(expression("  " ~ kappa)) +geom_point(size=1) +xlim(1,8) +ylim(0,0.05)+ylab("VI")+ggtitle(expression("                " ~ sigma == 0.05))
plot3<- ggplot(data3,aes(x=kap[seq(1,71,2)], y= data3$VI_DIST.3....seq.1..71..2...128.2))+geom_line(lwd=0.5) +xlab(expression("  " ~ kappa)) +geom_point(size=1) +xlim(1,8) +ylim(0,0.05)+ylab("VI")+ggtitle(expression("                " ~ sigma == 0.08))

# Use grid.arrange to put plots in columns
grid.arrange(plot1, plot2, plot3, ncol=3)

##=========================================##



##=== Alternative Plot ==##

## Plot of the distance for different noise level##
xdata <- kap
y1 <- VI_DIST[1,]/128^2
y2 <- VI_DIST[2,]/128^2
y3 <- VI_DIST[3,]/128^2

# plot the first curve by calling plot() function
# First curve is plotted
plot(xdata, y1, type="o", pch=21, lty=1, ylim=c(0,0.05),xlab="Tuning Parameter Kappa",ylab="Variation of information",main="Selection of Kappa for 64*64 Image" )

# Add second curve to the same plot by calling points() and lines()
# Use symbol '*' for points.
points(xdata, y2, pch="*")
lines(xdata, y2,lty=2)

# Add Third curve to the same plot by calling points() and lines()
# Use symbol '+' for points.
points(xdata, y3,pch="+")
lines(xdata, y3, lty=3)
##===============================================##   