
## Image for Demonstration ## 
par(mfrow=c(1,2),mai = c(0.1, 0.1, 0.1,0.1))
img=matrix(0,256,256)
img[96:162,110:150]=1
image(img,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))
nimg=img+matrix(rnorm(nrow(img)*ncol(img),0,0.03),nrow=nrow(img),ncol=ncol(img))
image(nimg,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))

shadow=matrix(0,256,256)
shadow[1:128,]=0.05
shadow[129:256,129:256]=0.1
image(nimg+shadow,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))
