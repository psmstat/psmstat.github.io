## Plot for selection of Bandwidth parameter (h_n) ##

#======== surfaceCluster_bandwidth() ============#

library(DRIP)
library(ggplot2) 
library(gridExtra) 

#=====  Image Size=64*64 =====#
x=matrix(0,nrow=64,ncol=64)
for(i in 1:64){
  for(j in 1:64){
    if(((i-32)^2+(j-32)^2<64)){
      x[i,j]=1
    }
  }
}
image(x,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))
set.seed(2023)
data1=surfaceCluster_bandwidth(image=(x+matrix(rnorm(nrow(x)*ncol(x),0,0.03),nrow=nrow(x),ncol=ncol(x)) ),bandwidths=c(2:10), sig.level=.9995, blur=F)$cv_dataframe
data2=surfaceCluster_bandwidth(image=(x+matrix(rnorm(nrow(x)*ncol(x),0,0.05),nrow=nrow(x),ncol=ncol(x)) ),bandwidths=c(2:10), sig.level=.9995, blur=F)$cv_dataframe
data3=surfaceCluster_bandwidth(image=(x+matrix(rnorm(nrow(x)*ncol(x),0,0.08),nrow=nrow(x),ncol=ncol(x)) ),bandwidths=c(2:10), sig.level=.9995, blur=F)$cv_dataframe
par(mfrow=c(1,3))
plot1=ggplot(data1,aes(x=data1$bandwidths, y=data1$cv))+geom_line()+geom_point()+xlab(expression(h[n]))+ylim(0,0.03)+ggtitle(expression("         "~sigma==0.03))+ylab("CV Score")
plot2=ggplot(data2,aes(x=data2$bandwidths, y=data2$cv))+geom_line()+geom_point()+xlab(expression(h[n]))+ylim(0,0.03)+ggtitle(expression("         "~sigma==0.05))+ylab("CV Score")
plot3=ggplot(data3,aes(x=data3$bandwidths, y=data3$cv))+geom_line()+geom_point()+xlab(expression(h[n]))+ylim(0,0.03)+ggtitle(expression("         "~sigma==0.08))+ylab("CV Score")

# Use grid.arrange to put plots in columns 
grid.arrange(plot1, plot2, plot3, ncol=3)

#=======  Image Size=128*128 ========#
x=matrix(0,nrow=128,ncol=128)
for(i in 1:128){
  for(j in 1:128){
    if(((i-64)^2+(j-64)^2<256)){
      x[i,j]=1
    }
  }
}
image(x,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))


set.seed(2023)
data1=surfaceCluster_bandwidth(image=(x+matrix(rnorm(nrow(x)*ncol(x),0,0.03),nrow=nrow(x),ncol=ncol(x)) ),bandwidths=c(2:10), sig.level=.9995, blur=F)$cv_dataframe
data2=surfaceCluster_bandwidth(image=(x+matrix(rnorm(nrow(x)*ncol(x),0,0.05),nrow=nrow(x),ncol=ncol(x)) ),bandwidths=c(2:10), sig.level=.9995, blur=F)$cv_dataframe
data3=surfaceCluster_bandwidth(image=(x+matrix(rnorm(nrow(x)*ncol(x),0,0.08),nrow=nrow(x),ncol=ncol(x)) ),bandwidths=c(2:10), sig.level=.9995, blur=F)$cv_dataframe
par(mfrow=c(1,3))
plot1=ggplot(data1,aes(x=data1$bandwidths, y=data1$cv))+geom_line()+geom_point()+xlab(expression(h[n]))+ylim(0,0.03)+ggtitle(expression("         "~sigma==0.03))+ylab("CV Score")
plot2=ggplot(data2,aes(x=data2$bandwidths, y=data2$cv))+geom_line()+geom_point()+xlab(expression(h[n]))+ylim(0,0.03)+ggtitle(expression("         "~sigma==0.05))+ylab("CV Score")
plot3=ggplot(data3,aes(x=data3$bandwidths, y=data3$cv))+geom_line()+geom_point()+xlab(expression(h[n]))+ylim(0,0.03)+ggtitle(expression("         "~sigma==0.08))+ylab("CV Score")
