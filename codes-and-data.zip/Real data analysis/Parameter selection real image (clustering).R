## Calculate Number of Cluster ##

library(magic)
library(pracma) 
library(jpeg)
library(DRIP)
library(mcclust)
library(matlab)

x1=readJPEG("2016.jpg")[200:600,400:800,1]
image(rot90(x1,3),useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))#2016 image
y1=readJPEG("2018_1.jpg")[200:600,406:806,1]
image(rot90(y1,3),useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))#2018 image
z1=readJPEG("2022.jpg")[200:600,426:826,1]
image(rot90(z1,3),useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))#2022 image

x=x1[225:350,225:350]
y=y1[225:350,225:350]
z=z1[225:350,225:350]
# z=z1[1:125,1:125]   # Only background disturbance 
image(x,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))
Im_1=x
est_Im_1=surfaceCluster(Im_1,3,0.999,plot=T)
residual=Im_1-est_Im_1$estImg
sigma_hat=est_Im_1$sigma
hist(q)

### How many element in a circular neighborhood? ###
h=3
g=expand.grid(-h:h,-h:h)
g$d2 = sqrt ((g$Var1)^2 + (g$Var2)^2)
n_cir = length(g$d2[g$d2<=h])


### Function to extract y for each (i,j)^th pixel of image ###
extract_y=function(A,i,j){
  p=10 #padded size
  m_1=apad(A,c(p,p),method="mirror")
  m_2=rbind(m_1[p:1,],m_1)
  M=cbind(m_2[,p:1],m_2)
  h=3
  i1=i+p
  j1=j+p
  g = expand.grid((i1-h):(i1+h),(j1-h):(j1+h))
  g$d2 = sqrt ((g$Var1-i1)^2 + (g$Var2-j1)^2)
  g$inside = g$d2<=h
  y=M[as.matrix(g[g$inside,c("Var1","Var2")])]
  return(y)
}

################################################################################

### Function for optimal value of s ###
opt_s=function(y){
  T_s=c()
  length(y)
  minimum=min(y)
  maximum=max(y)
  v=seq(minimum,maximum,0.005)
  for( k in 1:length(v)){
    y_1=y[y>v[k]]
    y_2=y[y<=v[k]]
    T_s[k]=((length(y_1)*(mean(y_1)-mean(y))^2)+(length(y_2)*(mean(y_2)-mean(y))^2))/(sum((y_1-mean(y_1))^2)+sum((y_2-mean(y_2))^2))
  }
  return(v[which.max(T_s)])
}

################################################################################

library(DRIP)
G=array(0,dim=c(1,n_cir,(nrow(x))^2))
k=0
for(i in 1:nrow(x)){
  for(j in 1:ncol(x)){
    k=k+1
    G[,,k]=extract_y(Im_1,i,j)
    
  }
}
cut_off=apply(G, 3, opt_s)

sigma_hat = JPLLK_surface(Im_1,3, plot = FALSE)$sigma

n_clust=c()
kappa_vec=seq(1,20,by=0.5)
for(i in 1:length(kappa_vec)){
  G_cluster=array(0,dim=c(1,n_cir,(nrow(x))^2))
  for(k in 1:(nrow(x))^2){
    if(std(c(G[,,k]))<kappa_vec[i]*sigma_hat){    
      G_cluster[,,k]=rep(0,29)
    }else{
      G_cluster[,,k]=ifelse(G[,,k]> cut_off[k],1,0)
    }
  }
  n_clust[i]=sum(ifelse(apply(G_cluster,1,sum)>0,1,0))
}

ggplot(data.frame(n_clust,kappa_vec),aes(x=kappa_vec, y= n_clust))+geom_line(lwd=1) +xlab(expression(~ kappa))+xlim(0,20) +ylim(0,6000)+ylab("# neighborhoods with clustering")
