## Selection of Kappa for Real Image (Bootstrap Procedure) ##

library(magic)
library(pracma) 
library(jpeg)
library(DRIP)
library(mcclust)


### Real Image ###
x1=readJPEG("2016.jpg")[200:600,400:800,1]
image(rot90(x1,3),useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))#2016 image
x=x1[225:350,225:350]

### How many element in a circular neighborhood? ###
h=3
g=expand.grid(-ceiling(h):ceiling(h),-ceiling(h):ceiling(h))
g$d2 = sqrt ((g$Var1)^2 + (g$Var2)^2)
n_cir = length(g$d2[g$d2<=h])

### Function to extract y for each (i,j)^th pixel of image ###
extract_y=function(A,i,j){
  p=10 #padded size
  m_1=apad(A,c(p,p),method="mirror")
  m_2=rbind(m_1[p:1,],m_1)
  M=cbind(m_2[,p:1],m_2)
  h=3
  i1=i+p
  j1=j+p
  g = expand.grid((i1-ceiling(h)):(i1+ceiling(h)),(j1-ceiling(h)):(j1+ceiling(h)))
  g$d2 = sqrt ((g$Var1-i1)^2 + (g$Var2-j1)^2)
  g$inside = g$d2<=h
  y=M[as.matrix(g[g$inside,c("Var1","Var2")])]
  return(y)
}

### Function for optimal value of s ###
opt_s=function(y){
  T_s=c()
  length(y)
  minimum=min(y)
  maximum=max(y)
  v=seq(minimum,maximum,0.0025)
  for( k in 1:length(v)){
    y_1=y[y>v[k]]
    y_2=y[y<=v[k]]
    T_s[k]=((length(y_1)*(mean(y_1)-mean(y))^2)+(length(y_2)*(mean(y_2)-mean(y))^2))/(sum((y_1-mean(y_1))^2)+sum((y_2-mean(y_2))^2))
  }
  return(v[which.max(T_s)])
}

## Function for clustering ##
H1=function(x,kap){
  library(DRIP)
  G=array(0,dim=c(1,n_cir,(nrow(x))^2))
  k=0
  for(i in 1:nrow(x)){
    for(j in 1:ncol(x)){
      k=k+1
      G[,,k]=extract_y(x,i,j)
      
    }
  }
  cut_off=apply(G, 3, opt_s)
  
  sigma_hat = JPLLK_surface(x,3, plot = FALSE)$sigma
  G_cluster=array(0,dim=c(1,n_cir,(nrow(x))^2))
  for(k in 1:(nrow(x))^2){
    if(std(c(G[,,k]))<kap*sigma_hat){    #choose 1.3 otherwise no of false cluste will be large
      G_cluster[,,k]=rep(0,n_cir)
    }else{
      G_cluster[,,k]=ifelse(G[,,k]> cut_off[k],1,0)
    }
    
  }
  return(G_cluster)
}


kap=seq(1,20,0.5)                         ## Different value of tuning parameter
VI_DIST=matrix(0,nrow=1,ncol=length(kap)) ## Matrix to store the value of VI distance
Im_1=x
image(Im_1,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))
est_Im_1=surfaceCluster(Im_1,3,0.999,plot=T)
residual=Im_1-est_Im_1$estImg
image(est_Im_1$estImg,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))
sigma_hat=est_Im_1$sigma
sigma_hat = JPLLK_surface(Im_1,3, plot = FALSE)$sigma


library(foreach)
library(doParallel)

#setup parallel backend to use many processors
cores=detectCores()
cl <- makeCluster(cores[1]-2) #not to overload computer
registerDoParallel(cl)

set.seed(2022)
n=50
M=array(0,dim=c(nrow(x),ncol(x),n))
MM=array(0,dim=c(1,n_cir,(nrow(x))^2))

for(i in 1:n){
  M[,,i]=est_Im_1$estImg+matrix(sample(residual,nrow(x)*ncol(x),replace = T),nrow=nrow(x),ncol=ncol(x))
}
image(matrix(residual,nrow=nrow(x),ncol=ncol(x)),useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))


for(v in 1:length(kap)){
  MM=H1(est_Im_1$estImg,kap[v])
  T_VI=foreach(i = 1:n,.combine = c)%dopar%{
    library(magic)
    library(pracma) 
    library(jpeg)
    library(DRIP)
    library(mcclust)
    MMM=H1(M[,,i],kap[v])
    s=0
    mm=c()
    for(k  in 1:(nrow(x))^2){
      mm[k]=vi.dist(MMM[,,k],MM[,,k])
      s=s+vi.dist(MMM[,,k],MM[,,k])
    }
    s
  }
  
  VI_DIST[1,v]=mean(T_VI)
}
## Normal Plot ##
plot(kap,VI_DIST,ylim=c(0,500),type="l")

## gg plot ##
ggplot(data.frame(VI_DIST,kap),aes(x=kap, y= VI_DIST))+geom_line(lwd=1) +xlab(expression(~ kappa))+xlim(0,20) +ylim(0,2500)+ylab("VI distance")

#############################################