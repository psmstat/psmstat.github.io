## Required Library ##
library(magic)
library(pracma) 
library(jpeg)
library(DRIP)
library(mcclust)
library(matlab)

## Registered image ##

x1=readJPEG("2016.jpg")[200:600,400:800,1]
image(rot90(x1,3),useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))#2016 image
y1=readJPEG("2018_1.jpg")[200:600,406:806,1]
image(rot90(y1,3),useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))#2018 image
z1=readJPEG("2022.jpg")[200:600,426:826,1]
image(rot90(z1,3),useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))#2022 image

## Crop image ##
x=x1[225:350,225:350]
y=y1[225:350,225:350]
z=z1[225:350,225:350]

Im_1=x                                 # Observed Image 1 (image of Aral Sea in 2016)
image(rot90(Im_1,3),useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))
est_Im_1=surfaceCluster(Im_1,3,0.999,plot=T)
residual=Im_1-est_Im_1$estImg
image(Im_1-est_Im_1$estImg,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))
sigma_hat=est_Im_1$sigma


### How many element in a circular neighborhood? ###
h=3
g=expand.grid(-h:h,-h:h)
g$d2 = sqrt ((g$Var1)^2 + (g$Var2)^2)
n_cir = length(g$d2[g$d2<=h])


### Function to extract y for each (i,j)^th pixel of image ###
extract_y=function(A,i,j){
  p=10 #padded size
  m_1=apad(A,c(p,p),method="mirror")
  m_2=rbind(m_1[p:1,],m_1)
  M=cbind(m_2[,p:1],m_2)
  h=3
  i1=i+p
  j1=j+p
  g = expand.grid((i1-h):(i1+h),(j1-h):(j1+h))
  g$d2 = sqrt ((g$Var1-i1)^2 + (g$Var2-j1)^2)
  g$inside = g$d2<=h
  y=M[as.matrix(g[g$inside,c("Var1","Var2")])]
  return(y)
}

################################################################################

### Function for optimal value of s ###
opt_s=function(y){
  T_s=c()
  length(y)
  minimum=min(y)
  maximum=max(y)
  v=seq(minimum,maximum,0.0025)
  for( k in 1:length(v)){
    y_1=y[y>v[k]]
    y_2=y[y<=v[k]]
    T_s[k]=((length(y_1)*(mean(y_1)-mean(y))^2)+(length(y_2)*(mean(y_2)-mean(y))^2))/(sum((y_1-mean(y_1))^2)+sum((y_2-mean(y_2))^2))
  }
  return(v[which.max(T_s)])
}

################################################################################
### function based on modified hausdorff distance ####
H1=function(x){
  library(DRIP)
  G=array(0,dim=c(1,n_cir,(nrow(x))^2))
  k=0
  for(i in 1:nrow(x)){
    for(j in 1:ncol(x)){
      k=k+1
      G[,,k]=extract_y(M1[,,1],i,j)
      
    }
  }
  cut_off=apply(G, 3, opt_s)
  sigma_hat = JPLLK_surface(x,3, plot = FALSE)$sigma
  
  G_cluster=array(0,dim=c(1,n_cir,(nrow(x))^2))
  for(k in 1:(nrow(x))^2){
    if(std(c(G[,,k]))<4*sigma_hat){    # Choose the tuning parameter based on purpose
      G_cluster[,,k]=rep(0,n_cir)
    }else{
      G_cluster[,,k]=ifelse(G[,,k]> cut_off[k],1,0)
    }
    
  }
  return(G_cluster)
}
#################################################################################
  `
  library(foreach)
  library(doParallel)
  
  #setup parallel backend to use many processors
  cores=detectCores()
  cl <- makeCluster(cores[1]-1) #not to overload your computer
  registerDoParallel(cl)
  
  set.seed(2022)
  n=100                          #No of Bootstrap sample to generate null distribution 
  M1=array(0,dim=c(nrow(x),ncol(x),n))
  M2=array(0,dim=c(nrow(x),ncol(x),n))
  
  for(i in 1:n){
    M1[,,i]=est_Im_1$estImg+matrix(sample(residual,nrow(x)*ncol(x),replace = T),nrow=nrow(x),ncol=ncol(x))
    M2[,,i]=est_Im_1$estImg+matrix(sample(residual,nrow(x)*ncol(x),replace = T),nrow=nrow(x),ncol=ncol(x))
  }
  
T_VI=foreach(i = 1:n,.combine = c)%dopar%{
    library(magic)
    library(pracma) 
    library(jpeg)
    library(DRIP)
    library(mcclust)
    MMM1=H1(M1[,,i])
    MMM2=H1(M2[,,i])
    s=0
    mm=c()
    for(k  in 1:(nrow(x))^2){
      s=s+vi.dist(MMM1[,,k],MMM2[,,k])
    }
    s
    
  }
hist(T_VI)                      # Histogram of Null distribution
quantile(T_VI,0.99)             # Quantile of null distribution 


## Alternative images (Images of Aral Sea 2018/2022)##

a=surfaceCluster(y,3,0.999,plot=T)$estImg
re=y-surfaceCluster(y,3,0.999,plot=T)$estImg
image(re,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))

cores=detectCores()
cl <- makeCluster(cores[1]-1) #not to overload your computer
registerDoParallel(cl)

set.seed(2022)
n=100         #No of Bootstrap sample
M1=array(0,dim=c(nrow(x),ncol(x),n))
M2=array(0,dim=c(nrow(x),ncol(x),n))

for(i in 1:n){
  M1[,,i]=est_Im_1$estImg+matrix(sample(residual,nrow(x)*ncol(x),replace = T),nrow=nrow(x),ncol=ncol(x))
  M2[,,i]=a+matrix(sample(re,nrow(x)*ncol(x),replace = T),nrow=nrow(x),ncol=ncol(x))
  
}
image(M1[,,1],useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))
T_VI_a=foreach(i = 1:n,.combine = c)%dopar%{
  library(magic)
  library(pracma) 
  library(jpeg)
  library(DRIP)
  library(mcclust)
  MMM1=H1(M1[,,i])
  MMM2=H1(M2[,,i])
  s=0
  mm=c()
  for(k  in 1:(nrow(x))^2){
    s=s+vi.dist(MMM1[,,k],MMM2[,,k])
  }
  s
  
}


## Calculate estimated pvalue ##
pvalue=c()
for(i in 1:length(T_VI_a)){
  cdf_null=ecdf(T_VI)
  pvalue[i]=(1-cdf_null(T_VI_a[i]))
}
mean(pvalue)
