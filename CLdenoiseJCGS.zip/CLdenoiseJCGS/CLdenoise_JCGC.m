function estimate = CLdenoise_test2(noisyimage,nh,T,h)

nimg = noisyimage;
[n1 n2] = size(nimg);
bd = 20;
pnimg = zeros(2*bd+n1,2*bd+n2);
nhh = 1.0; grid = 5; nh1=nh; nh2=1; nh_c=3*nh; h_c=10*h;

pnimg(1+bd:n1+bd,1+bd:n2+bd)=nimg;
for i=bd+1:bd+n1; for j=1:bd; pnimg(i,j)=pnimg(i,2*bd-j+1);end;end;
for i=bd+1:bd+n1; for j=bd+n2+1:bd+n2+bd; pnimg(i,j)=pnimg(i,2*(bd+n2)-j+1);end;end;
for i=1:bd; for j=bd+1:bd+n2; pnimg(i,j)=pnimg(2*bd-i+1,j);end;end;
for i=bd+n1+1:bd+n1+bd; for j=bd+1:bd+n2; pnimg(i,j)=pnimg(2*(bd+n1)-i+1,j);end;end;
for i=1:bd; for j=1:bd; pnimg(i,j)=pnimg(2*bd-i+1,j);end;end;
for i=1:bd; for j=bd+n2+1:bd+n2+bd; pnimg(i,j)=pnimg(2*bd-i+1,j);end;end;
for i=bd+n1+1:bd+n1+bd; for j=1:bd; pnimg(i,j)=pnimg(2*(bd+n1)-i+1,j);end;end;
for i=bd+n1+1:bd+n1+bd; for j=bd+n2+1:bd+n2+bd; pnimg(i,j)=pnimg(2*(bd+n1)-i+1,j);end;end;


est = zeros(2*bd+n1,2*bd+n2);
est_lck = zeros(2*bd+n1,2*bd+n2);

sumtemp1=0;
for i=bd+1:bd+n1;
    for j=bd+1:bd+n2;
        c = 0;
        for i1=i-ceil(nhh):i+ceil(nhh);
            for j1=j-ceil(nhh):j+ceil(nhh);
                if ((i1-i)^2+(j1-j)^2 <= nhh^2)
                    c = c+1;
                    t(c) = pnimg(i1,j1); tloc1(c) = i1; tloc2(c) = j1;
                end;
            end;
        end;
        est_lck(i,j) = lck([tloc1' tloc2'],t',[i;j],nhh);
        sumtemp1 = sumtemp1 + (pnimg(i,j)-est_lck(i,j))^2;
    end;end;
sigmahat = sqrt(sumtemp1/(n1*n2));
        
        

for i=bd+1:bd+n1;
    for j=bd+1:bd+n2;
        c = 0;
        for i1=i-ceil(nh):i+ceil(nh);
            for j1=j-ceil(nh):j+ceil(nh);
                if ((i1-i)^2+(j1-j)^2 <= nh^2)
                    c = c+1;
                    t(c) = pnimg(i1,j1); tloc1(c) = i1; tloc2(c) = j1;
                end;
            end;
        end;
 
        if (var(t) < 1.0*sigmahat^2)
            
            cc = 0;
            for i1=i-ceil(nh_c):i+ceil(nh_c);
            for j1=j-ceil(nh_c):j+ceil(nh_c);
                if ((i1-i)^2+(j1-j)^2 <= nh_c^2)
                    cc = cc+1;
                    tt(cc) = pnimg(i1,j1);
                end;
            end;
            end;
            
            if (var(tt) < 1.0*sigmahat^2)
            s = 0; wt = 0; tempv1 = [pnimg(i,j) pnimg(i-1,j) pnimg(i+1,j) pnimg(i,j-1) pnimg(i,j+1) ...
                pnimg(i-1,j-1) pnimg(i-1,j+1) pnimg(i+1,j-1) pnimg(i+1,j+1)];
            weights = [1 1 1 1 1 1 1 1 1];
            for i1=i-ceil(nh_c):i+ceil(nh_c);
                for j1=j-ceil(nh_c):j+ceil(nh_c);
                    if ((i1-i)^2+(j1-j)^2 <= nh_c^2)
                        tempv2 = [pnimg(i1,j1) pnimg(i1-1,j1) pnimg(i1+1,j1) pnimg(i1,j1-1) pnimg(i1,j1+1) ...
                            pnimg(i1-1,j1-1) pnimg(i1-1,j1+1) pnimg(i1+1,j1-1) pnimg(i1+1,j1+1)];
                        w = exp(-((sum((tempv1 - tempv2).*weights).^2)/9)/(2*sigmahat^2*h_c));
                        wt = wt + w;
                        s = s + w*pnimg(i1,j1);
                    end;
                end;
            end;
            est(i,j) = s/wt;
            if (wt == 0)
                est(i,j) = pnimg(i,j);
            end;
            
            else
                
            s = 0; wt = 0; tempv1 = [pnimg(i,j) pnimg(i-1,j) pnimg(i+1,j) pnimg(i,j-1) pnimg(i,j+1) ...
                pnimg(i-1,j-1) pnimg(i-1,j+1) pnimg(i+1,j-1) pnimg(i+1,j+1)];
            weights = [1 1 1 1 1 1 1 1 1];
            for i1=i-ceil(nh1):i+ceil(nh1);
                for j1=j-ceil(nh1):j+ceil(nh1);
                    if ((i1-i)^2+(j1-j)^2 <= nh^2)
                        tempv2 = [pnimg(i1,j1) pnimg(i1-1,j1) pnimg(i1+1,j1) pnimg(i1,j1-1) pnimg(i1,j1+1) ...
                            pnimg(i1-1,j1-1) pnimg(i1-1,j1+1) pnimg(i1+1,j1-1) pnimg(i1+1,j1+1)];
                        w = exp(-((sum((tempv1 - tempv2).*weights).^2)/9)/(2*sigmahat^2*h));
                        wt = wt + w;
                        s = s + w*pnimg(i1,j1);
                    end;
                end;
            end;
            est(i,j) = s/wt;
            if (wt == 0)
                est(i,j) = pnimg(i,j);
            end;
            
            end
    
        else
            mx = max(t); mn = min(t);       
            if (mx == mn)
                teststat = zeros(grid-1,1);
            else
                for tt=1:grid-1
                    tempsep = mn+(tt*(mx-mn))/grid;
                    gr1 = t((t<=tempsep)); gr2=setdiff(t,gr1);
                    ssw = (std(gr1,1))^2*(length(gr1)) + (std(gr2,1))^2*(length(gr2));
                    ssb = (std(t,1))^2*(c) - ssw;
                        if (ssw == 0)
                            teststat(tt) = 999999;
                        else
                            teststat(tt) = ssb/ssw;
                        end
                end
            end
            [m ind] = max(teststat);

            if (m < T)
                s = 0; wt = 0; tempv1 = [pnimg(i,j) pnimg(i-1,j) pnimg(i+1,j) pnimg(i,j-1) pnimg(i,j+1)];
                for i1=i-ceil(nh1):i+ceil(nh1);
                    for j1=j-ceil(nh1):j+ceil(nh1);
                        if ((i1-i)^2+(j1-j)^2 <= nh^2)
                            tempv2 = [pnimg(i1,j1) pnimg(i1-1,j1) pnimg(i1+1,j1) pnimg(i1,j1-1) pnimg(i1,j1+1)];
                            w = exp(-((sum(tempv1 - tempv2).^2)/5)/(2*sigmahat^2*h));
                            wt = wt + w;
                            s = s + w*pnimg(i1,j1);
                        end
                    end
                end
                est(i,j) = s/wt;
                if (wt == 0)
                    est(i,j) = pnimg(i,j);
                end
       
       
            else
                tempsep = mn+(ind*(mx-mn))/grid;
                cgr1 = find(t<=tempsep); cgr2 = setdiff(1:c,cgr1);
                gr1 = t(cgr1); gr2 = t(cgr2);
                locinfo = pnimg(i:i,j:j);
                locm = mean(locinfo(:));
       
                if (abs(locm-mean(gr1)) < abs(locm-mean(gr2)))
                    s = 0; wt = 0; tempv1 = [pnimg(i,j) pnimg(i-1,j) pnimg(i+1,j) pnimg(i,j-1) pnimg(i,j+1)];
                    for i1=i-ceil(nh1):i+ceil(nh1);
                        for j1=j-ceil(nh1):j+ceil(nh1);
                            % already considering circular
                            if (ismember(pnimg(i1,j1),gr1)==1)
                                tempv2 = [pnimg(i1,j1) pnimg(i1-1,j1) pnimg(i1+1,j1) pnimg(i1,j1-1) pnimg(i1,j1+1)];
                                w = exp(-((sum(tempv1 - tempv2).^2)/5)/(2*sigmahat^2*h));
                                wt = wt + w;
                                s = s + w*pnimg(i1,j1);
                            end;
                        end
                    end
                    est(i,j) = s/wt;
                    if (wt == 0)
                        est(i,j) = pnimg(i,j);
                    end;
                else
                    s = 0; wt = 0; tempv1 = [pnimg(i,j) pnimg(i-1,j) pnimg(i+1,j) pnimg(i,j-1) pnimg(i,j+1)];
                        for i1=i-ceil(nh1):i+ceil(nh1)
                            for j1=j-ceil(nh1):j+ceil(nh1);
                                % already considering circular
                                if (ismember(pnimg(i1,j1),gr2)==1)
                                    tempv2 = [pnimg(i1,j1) pnimg(i1-1,j1) pnimg(i1+1,j1) pnimg(i1,j1-1) pnimg(i1,j1+1)];
                                    w = exp(-((sum(tempv1 - tempv2).^2)/5)/(2*sigmahat^2*h));
                                    wt = wt + w;
                                    s = s + w*pnimg(i1,j1);
                                end;
                            end
                        end
                    est(i,j) = s/wt;
                    if (wt == 0)
                        est(i,j)= pnimg(i,j);
                    end
                end
            end
            clear t gr1 gr2 teststat tloc1 tloc2 cgr1 cgr2 tt;
        end
    end
end

estimate = est(bd+1:bd+n1,bd+1:bd+n2);
