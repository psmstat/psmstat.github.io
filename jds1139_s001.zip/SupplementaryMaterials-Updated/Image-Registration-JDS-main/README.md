zooming.R is the main code file.
