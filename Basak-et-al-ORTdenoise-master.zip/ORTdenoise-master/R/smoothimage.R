
#' Title smoothimage
#'
#' @param img Image to be denoised
#' @param minlossimprove cutoff for branching
#' @param smband smoothing band
#' @param mode 1 uses the c implementation which is faster but use approximations, 2 uses the R implemetation but does not work on 3d mages
#' @returns smoothed image, and decision tree
#' @export
#'
#' @examples smoothimage(img,0,0001,4,1)
smoothimage <- function(img, minlossimprove = 0.0001, smband = 4,mode=1) {
  if(max(img>10)) scale_factor=255 else scale_factor=1
  img=img/scale_factor
  if(mode==1)
  {
  # Flatten image
    y <- as.vector(img)
    dims <- dim(img)
    p <- length(dims)

    # Build coordinate matrix with dummy column 1 using expand.grid
    dim_seq <- lapply(dims, seq_len)
    coords_df <- expand.grid(dim_seq)      # each row is a coordinate
    X <- cbind(1, as.matrix(coords_df))    # add dummy column

    # Create root node
    root_intensity <- y
    root_coord <- X

    # Build the tree using C++ function
    tree <- gettree_cpp(root_intensity, root_coord,
                        minlossimprove = minlossimprove,
                        minsize = 1)

    # Apply Treetomat smoothing
    res <- TreetomatPixelSIMD(tree, img,dim(img), smband)

    # Reshape back to original image dimensions
    res_array <- array(res, dim = dims)*scale_factor
  }
  if(mode==2)
  {
    y=c(img)
    x1=list()
    for(i in 1:nrow(img)){
      x1[[i]]=c(1:nrow(img))
    }
    x1=unlist(x1)
    x2=list()
    for(i in 1:nrow(img)){
      x2[[i]]=rep(i,nrow(img))
    }
    x2=unlist(x2)
    X=cbind(rep(1,length(x1)),x1,x2)
    root=list(intensity=y,coord=X,leaf=0)
    tree=gettree(root,minloss=minlossimprove)
    res_array = Rleaftomat(tree,img,smband)*scale_factor
  }
  return(list(image=res_array,tree=tree))
}

genroot = function(img)
{
  y=c(img)
  x1=list()
  for(i in 1:nrow(img)){
    x1[[i]]=c(1:ncol(img))
  }
  x1=unlist(x1)
  x2=list()
  for(i in 1:ncol(img)){
    x2[[i]]=rep(i,nrow(img))
  }
  x2=unlist(x2)
  X=cbind(rep(1,length(x1)),x1,x2)
  return(list(intensity=y,coord=X,leaf=0))
}

getresval = function(node,w)
{
  x=node$coord
  y=node$intensity
  w = w/sum(w^2)^0.5
  xmod = x%*%w
  fit1=y[xmod>0]
  fit2=y[xmod<=0]
  #res= sum(fit1)^2/(length(fit1)+0.00000000001)+sum(fit2)^2/(length(fit2)+0.0000000000001)
  n=length(y)
  n1=length(fit1)
  n2=length(fit2)
  if(n1<=1 || n2<=1 || n<=1) return(0)
  res=var(y)-(n1/n)*var(fit1)-(n2/n)*var(fit2)
  if(is.na(res)) cat(n1,n2,n)
  return(res)
}

optim_func_gen = function(node)
{
  f = function(w)
  {
    res = getresval(node,w)
    return(-res)
  }
  return(f)
}

getchild = function(node,minsize,minlossimprove=0.01)
{
  if(node$leaf==1)
  {
    return(list(node))
  }
  y=node$intensity
  X=node$coord
  optim_func= optim_func_gen(node)
  w_init=c(-ncol(X[,-1])*mean(X[,-1]),rep(1,ncol(X)-1))
  w_opti=optim(w_init,optim_func,control=list(maxit=1000000))
  w_conv=w_opti$conv
  w_opti=w_opti$par
  # if(w_conv)cat("conv--",w_conv,'\n')
  xmod=X%*%w_opti
  fit1=xmod>0
  fit2=xmod<=0
  lsimp=-optim_func(w_opti)
  child_left= list(intensity = y[fit1],coord = X[fit1,],leaf=0)
  child_right=list(intensity = y[fit2],coord = X[fit2,],leaf=0)
  if((lsimp > minlossimprove) &&
     (length(child_left$intensity)>minsize &&
      length(child_right$intensity)>minsize)
  )
  {
    return(list(child_left,child_right))
  }
  else
  {
    res=node
    res$leaf=1
    return(list(res))
  }
}


getnextgen=function(leaf_nodes,minsize,minlossimprove=0.01)
{
  res=list()
  it=1
  for(node in leaf_nodes)
  {
    if(node$leaf==1)
    {
      res=append(res,list(node))
    }
    else
    {
      temp=getchild(node,minsize,minlossimprove)
      res=append(res,temp)
    }
    it=it+1
  }
  return(res)
}

gettree = function(root,minlossimprove=0.01,minsize=1)
{
  res=list(root)
  it=0
  while(1)
  {
    res1=getnextgen(res,minsize,minlossimprove)
    if(length(res)==length(res1))
    {
      return(res1)
    }
    res=res1
    it=it+1

  }

}


Rleaftomat = function(tree,img,smband)
{
  # Set up parallel computing
  cl <- makeCluster(detectCores(logical = TRUE)-2)
  registerDoParallel(cl)
  # `%dopar%` <- foreach::`%dopar%`
  # `%do%` <- foreach::`%do%`
  # `%:%` <- foreach::`%:%`
  res = img
  nr=nrow(img)
  nc=ncol(img)
  img = Marknodes(tree,img)
  res = foreach(i= 1:nrow(img[,,1]),.combine=rbind,.inorder=FALSE) %:%
    foreach(j= 1:ncol(img[,,1]),.combine=cbind,.inorder=FALSE) %dopar%
    {
      temp=0
      count=0
      for(p in (-smband):smband)
      {
        loc1=nr-abs(nr-1-abs(i+p-1))
        for(q in (-smband):smband)
        {
          loc2=nc-abs(nc-1-abs(j+q-1))
          if(i==loc1 && j==loc2)
          {
            wt=1
          }
          else {
            wt = exp(-(img[loc1,loc2,1]-img[i,j,1])/sum((c(i,j)-c(loc1,loc2))^2)^0.5)
          }
          temp= temp+img[loc1,loc2,1]*(img[loc1,loc2,2]==img[i,j,2])*wt
          count =  count + (img[loc1,loc2,2]==img[i,j,2])*wt
        }
      }
      return(temp/count)
    }
  return(res)
}
edgeMSE=function(img,res,plot=FALSE)
{
  edge=stepEdge(image = img,bandwidth = 4,degree = 0,thresh = 0.2)
  edge1=stepEdge(image = res,bandwidth = 4,degree = 0,thresh = 0.2)
  if(plot)
  {
    image(edge,col=gray(0:256/256))
    image(edge1,col=gray(0:256/256))
  }
  return(dKQ(edge,edge1))
}
