##===============================================================##
## An Image Monitoring Control Chart for Detecting Small Changes ##
##===== Anik Roy & Partha Sarathi Mukherjee  ======##
##===== Indian Statistical Institute, Kolkata =====##
##===============================================================##

##=== Required R packages ===##
library(DRIP)

##=== Function For Cluster Based Image Denoising- (Mukherjee & Qiu) ===##


Clust_surface_estimate=function(nimg,h,Threshold){
  library(magic)
  sdn=function(x){
    xbar=mean(x)
    s=0
    for(i in 1:length(x)){
      s=s+(x[i]-xbar)^2
    }
    return(sqrt(s/length(x)))
  }
  
  n1=nrow(nimg)
  n2=ncol(nimg)
  bd=20
  m_1=apad(nimg,c(bd,bd),method="mirror")#padding step-1
  m_2=rbind(m_1[bd:1,],m_1)#padding step-2
  pnimg=cbind(m_2[,bd:1],m_2)#padded image matrix
  nhh=1
  grid=5
  nh1=3
  nh=3#### value of nh should be chosen by practitioner
  nh2=1
  nh_c=3*nh
  h=3
  h_c=10*h #### value of h should be chosen by practitioner
  library(DRIP)
  est_lck=JPLLK_surface(nimg, 3, plot = TRUE)
  sigmahat=est_lck$sigma
  
  #####################################################################################
  
  est=matrix(0,nrow=(bd+n1),ncol=(n2+bd))
  for(i in (bd+1):(bd+n1)){
    for(j in (bd+1):(bd+n2)){
      c=0
      tt=c()
      tloc1=c()
      tloc2=c()
      for(i1 in (i-ceiling(nh)):(i+ceiling(nh))){
        for(j1 in (j-ceiling(nh)):(j+ceiling(nh))){
          if((i1-i)^2+(j1-j)^2 <= nh^2){
            c=c+1
            tt[c]=pnimg[i1,j1]
            tloc1[c]=i1
            tloc2[c]=j1
          }
        }
      }
      
      if(var(tt)<1.0*sigmahat^2){
        cc=0
        ttt=c()
        for(i1 in (i-ceiling(nh_c)):(i+ceiling(nh_c))){
          for(j1 in (j-ceiling(nh_c)):(j+ceiling(nh_c))){
            if((i1-i)^2+(j1-j)^2 <= nh_c^2){
              cc=cc+1
              ttt[cc]=pnimg[i1,j1]
            }
          }
        }
        
        if(var(ttt)< 1.0*sigmahat^2){
          s=0
          wt=0
          tempv1=c(pnimg[i,j],pnimg[i-1,j],pnimg[i+1,j],pnimg[i,j-1],pnimg[i,j+1],pnimg[i-1,j-1],pnimg[i-1,j+1],pnimg[i+1,j-1],pnimg[i+1,j+1])
          weights=c(1,1,1,1,1,1,1,1,1)
          for(i1 in setdiff((i-ceiling(nh_c)):(i+ceiling(nh_c)),i)){
            for(j1 in setdiff((j-ceiling(nh_c)):(j+ceiling(nh_c)),j)){
              if((i1-i)^2+(j1-j)^2 <= nh_c^2){
                tempv2=c(pnimg[i1,j1],pnimg[i1-1,j1],pnimg[i1+1,j1],pnimg[i1,j1-1],pnimg[i1,j1+1],pnimg[i1-1,j1-1],pnimg[i1-1,j1+1],pnimg[i1+1,j1-1],pnimg[i1+1,j1+1])
                w=exp(-((sum((tempv1-tempv2)%*%weights)^2)/9)/(2*sigmahat^2*h_c))
                wt=wt+w
                s=s+w*pnimg[i1,j1]
              }
            }
          }
          
          est[i,j]=s/wt
          if(wt==0){
            est[i,j]=pnimg[i,j]
          }
        }
        else{
          s=0
          wt=0
          tempv1=c(pnimg[i,j],pnimg[i-1,j],pnimg[i+1,j],pnimg[i,j-1],pnimg[i,j+1],pnimg[i-1,j-1],pnimg[i-1,j+1],pnimg[i+1,j-1],pnimg[i+1,j+1])
          weights=c(1,1,1,1,1,1,1,1,1)
          for(i1 in setdiff((i-ceiling(nh1)):(i+ceiling(nh1)),i)){
            for(j1 in setdiff((j-ceiling(nh1)):(j+ceiling(nh1)),j)){
              if((i1-i)^2+(j1-j)^2 <= nh1^2){
                tempv2=c(pnimg[i1,j1],pnimg[i1-1,j1],pnimg[i1+1,j1],pnimg[i1,j1-1],pnimg[i1,j1+1],pnimg[i1-1,j1-1],pnimg[i1-1,j1+1],pnimg[i1+1,j1-1],pnimg[i1+1,j1+1])
                w=exp(-((sum((tempv1-tempv2)%*%weights)^2)/9)/(2*sigmahat^2*h))
                
                wt=wt+w
                s=s+w*pnimg[i1,j1]
              }
            }
          }
          
          est[i,j]=s/wt
          if(wt==0){
            est[i,j]=pnimg[i,j]
          }
        }
      }
      else{
        teststat=c()
        mx=max(tt)
        mn=min(tt)
        if(mx==mn){
          teststat=rep(0,(grid-1))
        }
        else{
          for(l in 1:(grid-1)){
            
            tempsep=mn+(l*(mx-mn))/grid
            gr1=tt[tt<=tempsep]
            gr2=c(setdiff(tt,gr1))
            ssw=(sdn(gr1))^2*(length(gr1))+(sdn(gr2))^2*(length(gr2))
            ssb=(sdn(tt))^2*(c)-ssw
            if(ssw==0){
              teststat[l]=999999
            }
            else{
              teststat[l]=ssb/ssw
            }
          }
        }
        m=max(teststat)
        ind=which.max(teststat)                         ##threshold should be given by practitioner
        if(m< Threshold){
          s=0
          wt=0
          tempv1=c(pnimg[i,j],pnimg[i-1,j],pnimg[i+1,j],pnimg[i,j-1],pnimg[i,j+1],pnimg[i-1,j-1],pnimg[i-1,j+1],pnimg[i+1,j-1],pnimg[i+1,j+1])
          weights=c(1,1,1,1,1,1,1,1,1)
          for(i1 in setdiff((i-ceiling(nh_c)):(i+ceiling(nh_c)),i)){
            for(j1 in setdiff((j-ceiling(nh_c)):(j+ceiling(nh_c)),j)){
              if((i1-i)^2+(j1-j)^2 <= nh_c^2){
                tempv2=c(pnimg[i1,j1],pnimg[i1-1,j1],pnimg[i1+1,j1],pnimg[i1,j1-1],pnimg[i1,j1+1],pnimg[i1-1,j1-1],pnimg[i1-1,j1+1],pnimg[i1+1,j1-1],pnimg[i1+1,j1+1])
                w=exp(-((sum((tempv1-tempv2)%*%weights)^2)/5)/(2*sigmahat^2*h))
                
                wt=wt+w
                s=s+w*pnimg[i1,j1]
              }
            }
          }
          est[i,j]=s/wt
          if(wt==0){
            est[i,j]=pnimg[i,j]
          }
          
        }else{
          tempsep=mn+(ind*(mx-mn))/grid
          cgr1=which(tt<=tempsep)
          cgr2=setdiff(1:c,cgr1)
          gr1=tt[cgr1]
          gr2=tt[cgr2]
          locinfo=pnimg[i,j]
          locm=mean(locinfo)
          
          
          if(abs(locm-mean(gr1)) < abs(locm-mean(gr2))){
            s=0
            wt=0
            tempv1=c(pnimg[i,j],pnimg[i-1,j],pnimg[i+1,j],pnimg[i,j-1],pnimg[i,j+1])
            for(i1 in setdiff((i-ceiling(nh1)):(i+ceiling(nh1)),i)){
              for(j1 in setdiff((j-ceiling(nh1)):(j+ceiling(nh1)),j)){
                if(as.integer(is.element(pnimg[i1,j1],gr1)==1)){
                  tempv2=c(pnimg[i1,j1],pnimg[i1-1,j1],pnimg[i1+1,j1],pnimg[i1,j1-1],pnimg[i1,j1+1])
                  w=exp(-((sum((tempv1-tempv2))^2)/5)/(2*sigmahat^2*h))
                  wt=wt+w
                  s=s+w*pnimg[i1,j1]
                }
              }
            }
            est[i,j]=s/wt
            if(wt==0){
              est[i,j]=pnimg[i,j]
            }
          }
          else{
            s=0
            wt=0
            tempv1=c(pnimg[i,j],pnimg[i-1,j],pnimg[i+1,j],pnimg[i,j-1],pnimg[i,j+1])
            for(i1 in setdiff((i-ceiling(nh1)):(i+ceiling(nh1)),i)){
              for(j1 in setdiff((j-ceiling(nh1)):(j+ceiling(nh1)),j)){
                if(as.integer(is.element(pnimg[i1,j1],gr2)==1)){
                  tempv2=c(pnimg[i1,j1],pnimg[i1-1,j1],pnimg[i1+1,j1],pnimg[i1,j1-1],pnimg[i1,j1+1])
                  w=exp(-((sum((tempv1-tempv2))^2)/5)/(2*sigmahat^2*h))
                  wt=wt+w
                  s=s+w*pnimg[i1,j1]
                }
              }
            }
            est[i,j]=s/wt
            if(wt==0){
              est[i,j]=pnimg[i,j]
            }
            
          }
          
        }                  
      }
    }
  }
  
  return(est[(bd+1):(bd+n1),(bd+1):(bd+n2)])
}  
  #### Pixel-wise local Likelihood ratio-based CUSUM Statistic ###
  
  likelihood=function(f0_hat,f1_hat,Im_obs,sigma_hat){
    Cn=matrix(0,nrow(Im_obs),ncol(Im_obs))
    en=(Im_obs-f0_hat)/sigma_hat
    for(i in 1:nrow(Im_obs)){
      for(j in 1:ncol(Im_obs)){
        Cn[i,j]=(f1_hat[i,j]-f0_hat[i,j])*(en[i,j]-(f1_hat[i,j]-f0_hat[i,j])/2)
      }
    }
    return(Cn)
  }
  
  
  
  ## True in-control image (Size 64*64) ##
  
  x=matrix(0,64,64)
  k=0
  for(i in 22:42){
    x[(32-k):(32+k),i]=1
    k=k+1
  }
  for(i in 30:50){
    x[(32-k):(32+k),i]=1
    k=k-1
  }
  image(x,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))
  
  
  ##=== Phase-I Estimation ===##
  
  m=10 # No of IC images
  f=array(0,dim=c(nrow(x),ncol(x),m))
  f0=matrix(0,nrow=nrow(x),ncol=ncol(x)) 
  
  for(i in 1:m){
    nimg=x+matrix(rnorm(nrow(x)*ncol(x),0,0.03),nrow=nrow(x),ncol=ncol(x))
    f[,,i]=Clust_surface_estimate(nimg,3,0)
    f0=f0+f[,,i]
  }
  f0_hat=(1/m)*f0   #  Estimate of true in-control image.
  image(f0_hat,col=gray(0:256/256))
  
  
  
  ##==== Estimate of Sigma for Bootstrapping ===##
  s_hat=JPLLK_surface(f[,,1], 3, plot = TRUE)$sigma
  
  
  ##=== Required Library for Parallel Computing ===##
  library(foreach)
  library(doParallel)
  
  
  ##=== To set in-control ARL = 20 ===##
  
  r=ceiling((nrow(x)^2)/10)
  #setup parallel backend to use many processors
  cores=detectCores()
  cl <- makeCluster(cores[1]-2) #not to overload your computer
  registerDoParallel(cl)
  b=50
  count=foreach(i = 1:b,.combine = c)%dopar%{
    library(magic)
    library(pracma) 
    library(jpeg)
    library(DRIP)
    s=0
    c_k=0
    set.seed(2024+i)
    while(c_k<=12.35){
      s=s+1
      if (s <5){
        X=x+matrix(rnorm(nrow(x)*ncol(x),0,s_hat),nrow=nrow(x),ncol=ncol(x))
        est_X=Clust_surface_estimate(X,3,0)
      }else{
        X=x+matrix(rnorm(nrow(x)*ncol(x),0,s_hat),nrow=nrow(x),ncol=ncol(x))
        est_X=Clust_surface_estimate(X,3,0)
      }
      CC=matrix(0,nrow(x),ncol(x))
      for(p in 1:nrow(x)){
        for(q in 1:ncol(x)){
          CC[p,q]=max(0,(CC[p,q]+likelihood(f0_hat,est_X,X,s_hat)[p,q]))
        }
      }
      c_k=sum(sort(c(CC),decreasing = T)[1:r])
    }
    s
  }
  
mean(count) # This value should approximately 20 for b=500

## True out-of-control image- Square fault (Size 64*64) ##

shift_size=0.3 # Change shift size to generate table in the paper
m=matrix(0,64,64)
k=0
for(i in 22:42){
  m[(32-k):(32+k),i]=1
  k=k+1
}
for(i in 30:50){
  m[(32-k):(32+k),i]=1
  k=k-1
}
m[32:33,36:37]=(1-shift_size)  
image(m,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))

##=== To compute out-of-control ARL ===##

cores=detectCores()
cl <- makeCluster(cores[1]-2) #not to overload your computer
registerDoParallel(cl)
b=500
count=foreach(i = 1:b,.combine = c)%dopar%{
  library(magic)
  library(pracma) 
  library(jpeg)
  library(DRIP)
  s=0
  c_k=0
  set.seed(2024+i)
  while(c_k<=12.35){
    s=s+1
    if (s <5){
      X=x+matrix(rnorm(nrow(x)*ncol(x),0,s_hat),nrow=nrow(x),ncol=ncol(x))
      est_X=Clust_surface_estimate(X,3,0)
    }else{
      X=m+matrix(rnorm(nrow(x)*ncol(x),0,s_hat),nrow=nrow(x),ncol=ncol(x))
      est_X=Clust_surface_estimate(X,3,0)
    }
    CC=matrix(0,nrow(x),ncol(x))
    for(p in 1:nrow(x)){
      for(q in 1:ncol(x)){
        CC[p,q]=max(0,(CC[p,q]+likelihood(f0_hat,est_X,X,s_hat)[p,q]))
      }
      
      
    }
    c_k=sum(sort(c(CC),decreasing = T)[1:r])
  }
  s
}

count1=count-4
count2=ifelse(count1<=0,0,count1)
final_count=count2[count2 != 0]
mean_arl=mean(final_count)# mean ARL_1 value
sd(final_count) # standard deviation of ARL_1

