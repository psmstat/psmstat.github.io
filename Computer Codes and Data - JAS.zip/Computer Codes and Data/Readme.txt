** This is a README file containing the list of online supplements related to the paper titled "An Image Monitoring Control Chart for Detecting Small Changes" **


1. *R Codes* : R-Codes to reproduce the tables for simulated data and real data.
     
        # Demo.R : This is an demo R code with 5 itereations.
        # Max-CUSUM.R : R code for to generate table values of Max-CUSUM 
        # Upper -q(0.5%)- quantile- CUSUM.R : R code for to generate table values of upper 0.5% quantile CUSUM chart.
        # Upper -q(5%)- quantile- CUSUM.R : R code for to generate table values of upper 5% quantile CUSUM chart.
        # Upper -q(10%)- quantile- CUSUM.R : R code for to generate table values of upper 10% quantile CUSUM chart.
        # Simulated Images- Upper-q-quantile control chart.R : R-code to generate simulated images of different resolutions.
        # Real Image.R : R-code for analysing the real textile images.
        