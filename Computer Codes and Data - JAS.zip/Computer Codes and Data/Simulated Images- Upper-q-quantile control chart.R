##===============================================================##
## An Image Monitoring Control Chart for Detecting Small Changes ##
    ##===== Anik Roy & Partha Sarathi Mukherjee  ======##
    ##===== Indian Statistical Institute, Kolkata =====##
##===============================================================##

## True in-control image (Size 64*64) ##

x=matrix(0,64,64)
k=0
for(i in 22:42){
  x[(32-k):(32+k),i]=1
  k=k+1
}
for(i in 30:50){
  x[(32-k):(32+k),i]=1
  k=k-1
}
image(x,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))

## True out-of-control image- Square fault (Size 64*64) ##

shift_size=0.3 # Change shift size to generate table in the paper
m=matrix(0,64,64)
k=0
for(i in 22:42){
  m[(32-k):(32+k),i]=1
  k=k+1
}
for(i in 30:50){
  m[(32-k):(32+k),i]=1
  k=k-1
}
m[32:33,36:37]=(1-shift_size)  
image(m,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))

## True out-of-control image- Scratch (Size 64*64) ##

shift_size=0.3 # Change shift size to generate table in the paper
m=matrix(0,64,64)
k=0
for(i in 22:42){
  m[(32-k):(32+k),i]=1
  k=k+1
}
for(i in 30:50){
  m[(32-k):(32+k),i]=1
  k=k-1
}

m[31,36]=(1-shift_size)
m[32,37]=(1-shift_size)
m[33,38]=(1-shift_size)

image(m,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))

##============================================================================##

## True in-control image (Size 128*128) ##

x=matrix(0,128,128)
k=0
for(i in 44:84){
  x[(64-k):(64+k),i]=1
  k=k+1
}
for(i in 60:100){
  x[(64-k):(64+k),i]=1
  k=k-1
}
image(x,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))

## True out-of-control image- Square fault (Size 128*128) ##

shift_size=0.3  # Change shift size to generate table in the paper
m=matrix(0,128,128)
k=0
for(i in 44:84){
  m[(64-k):(64+k),i]=1
  k=k+1
}
for(i in 60:100){
  m[(64-k):(64+k),i]=1
  k=k-1
}
m[64:66,72:74]=(1-shift_size) 
image(m,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))


## True out-of-control image- Scratch (Size 128*128) ##

shift_size=0.3  # Change shift size to generate table in the paper
m=matrix(0,128,128)
k=0
for(i in 44:84){
  m[(64-k):(64+k),i]=1
  k=k+1
}
for(i in 60:100){
  m[(64-k):(64+k),i]=1
  k=k-1
}
m[62,72]=(1-shift_size) 
m[63,73]=(1-shift_size) 
m[64,74]=(1-shift_size) 
m[65,75]=(1-shift_size) 
m[66,76]=(1-shift_size) 

image(m,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))
##============================================================================##


## Additional Simulations ##

## True in-control image (Size 128*128) ##
x=matrix(0,128,128)
for(i in 1:128){
  for(j in 1:128){
    if(i+j<=176 && i+j>=80  ){
      x[i,j]=(1/4)*sin((i+j)/1)
    }else{
      x[i,j]=(1/4)*sin((i+j)/4)
    }
  }
}
image(x,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))

## True out-of-control image: Scratch ##
m=matrix(0,128,128)
for(i in 1:128){
  for(j in 1:128){
    if(i+j<=176 && i+j>=80  ){
      m[i,j]=(1/4)*sin((i+j)/1)
    }else{
      m[i,j]=(1/4)*sin((i+j)/4)
    }
  }
}

m[100,101]= (1/4)*sin(201)
m[101,102]= (1/4)*sin(203)
m[102,103]= (1/4)*sin(205)
m[103,104]= (1/4)*sin(207)
m[104,105]= (1/4)*sin(209)
m[105,106]= (1/4)*sin(211)
m[106,107]= (1/4)*sin(213)
m[107,108]= (1/4)*sin(215)
image(m,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))

## True out-of-control image: Pattern change ##
m=matrix(0,128,128)
for(i in 1:128){
  for(j in 1:128){
    if(i+j<=176 && i+j>=80  ){
      m[i,j]=(1/4)*sin((i+j)/1.05)
    }else{
      m[i,j]=(1/4)*sin((i+j)/4)
    }
  }
}
image(m,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))

## True out-of-control image: Multiple Faults ##

m=matrix(0,128,128)
for(i in 1:128){
  for(j in 1:128){
    if(i+j<=176 && i+j>=80  ){
      m[i,j]=(1/4)*sin((i+j)/1)
    }else{
      m[i,j]=(1/4)*sin((i+j)/4)
    }
  }
}


for(i in 1:128){
  for(j in 1:128){
    if((i-64)^2+(j-64)^2<2 ){
      m[i,j]=0.35
    }
  }
}

m[106,107]= 0
m[107,108]= 0
m[108,109]= 0
m[109,110]= 0
m[110,111]= 0
m[111,112]= 0
image(m,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))


