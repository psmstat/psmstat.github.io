** This is a README file containing a list of online supplements related to the paper title "Rotation and Translation Invariant Monitoring of Shape and Size in Image Data" **

** Requirements **

# R-Studio Version: 4.3.2
# DRIP package Version: 1.8
# OpenImageR package Version: 1.3.0

1. *Codes & Data*: R-Code to reproduce the tables for simulated data and real data.
     
        # R Code (Simulated Images)- On Shape and Size monitoring of image objects: An R-code to generate different simulated images
        # R Code- On Comparison Shape and Size of Image Object: An R-code to generate Table 1 and Table 2
        # Proposed Algorithm (Updated R code): An R-code for the proposed algorithm with updated DRIP package (Version: 2.3)
        # R Code (kappa=0.1)- On Monitoring Shape and Size of image objects: An R-code for online monitoring with allowance parameter = 0.1. (Useful to generate Table 3 partially)
        # R Code (kappa=0.5)- On Monitoring Shape and Size of image objects: An R-code for online monitoring with allowance parameter = 0.5. (Useful to generate Table 3 partially)
        # CV score (R code): Bandwidth parameter selection using Cross-Validation 
        # Amoeba Shape generation: Simulation of Amoeba-shaped image object generation 
        # Star shape generation: Simulation of Star-shaped image object generation 
        # S-shape: Simulation of S-shaped image object generation
        # Various Shape Descriptors: R code for competing methods using various shape descriptors
        # Train Image (Salton Sea Area): A folder that contains real Salton Sea images to set the control limit
        # Test Image (Salton Sea Area): A folder that contains real Salton Sea images to monitor (2015-2023)
        # real_salton_sea_area_monitoring(R Code): An R-code for monitoring real images



        
