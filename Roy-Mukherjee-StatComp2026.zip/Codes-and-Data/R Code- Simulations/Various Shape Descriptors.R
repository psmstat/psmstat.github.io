
#===========================================================================================================#
##=========== Competing Methods: Based on Various Shape Descriptors (Rstudio: version- 4.2.2) =============##
#===========================================================================================================#
#Remark : This code will generate the value from Table-3 with nh_n=3 and Star-H_1^(1) [cell no -(5,3)]



##==== Required Libraries ====##
library(foreach)
library(doParallel)
library(DRIP)
library(twosamples)
library(OpenImageR)
library(magic)
library(pracma)
library(jpeg)
library(SAFARI)

##================ True Star Shape Image Object ==========##
x=matrix(0,256,256)
k=0
for(i in 88:168){
  x[(128-k):(128+k),i]=1
  k=k+1
}
for(i in 120:200){
  x[(128-k):(128+k),i]=1
  k=k-1
}

image(x,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))

##========= Star- H_1^(1) ==========##
m1=matrix(0,256,256)
k=0
for(i in 88:168){
  m1[(128-k):(128+k),i]=1
  k=k+1
}
for(i in 120:200){
  m1[(128-k):(128+k),i]=1
  k=k-1
}
for(i in 1:256){
  for(j in 1:256){
    if((i-128)^2+(j-128)^2<33^2){
      m1[i,j]=1
    }
  }
}

image(m1,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))



## Compute various Shape descriptors from SAFARI packages in CRAN-R ##
shape_descriptor=function(X,h_n){
  #X: Image matrix
  #X=readJPEG("2004-1c1.jpg")[,,1]
  h_n= 3
  est_img=JPLLK_surface(X,3,plot = F)$fitted
  e=stepEdge(X,h_n,(qnorm(0.999,0,1)*JPLLK_surface(est_img,3)$sigma),degree=0,plot = F)
  e[1,]=0
  e[2,]=0
  e[,1]=0
  e[,2]=0
  e[nrow(X),]=0
  e[nrow(X)-1,]=0
  e[,ncol(X)]=0
  e[,ncol(X)-1]=0
  for(k in 1:nrow(X)){
    for(l in 1:ncol(X)){
      if(k>2 && l>2 && k< (nrow(X)-1) && l< (ncol(X)-1) && e[k,l]==1 &&  sum(e[(k-1):(k+1),(l-1):(l+1)])<=4){
        e[k,l]=0
      }

    }
  }
  e[1,]=0
  e[2,]=0
  e[,1]=0
  e[,2]=0
  e[nrow(X),]=0
  e[nrow(X)-1,]=0
  e[,ncol(X)]=0
  e[,ncol(X)-1]=0
  for(k in 1:nrow(X)){
    for(l in 1:ncol(X)){
      if(k>2 && l>2 && k< (nrow(X)-1) && l< (ncol(X)-1) && e[k,l]==1 &&  sum(e[(k-1):(k+1),(l-1):(l+1)])<=3){
        e[k,l]=0
      }

    }
  }
  e[1,]=0
  e[2,]=0
  e[,1]=0
  e[,2]=0
  e[nrow(X),]=0
  e[nrow(X)-1,]=0
  e[,ncol(X)]=0
  e[,ncol(X)-1]=0
  for(k in 1:nrow(X)){
    for(l in 1:ncol(X)){
      if(k>2 && l>2 && k< (nrow(X)-1) && l< (ncol(X)-1) && e[k,l]==1 &&  sum(e[(k-1):(k+1),(l-1):(l+1)])<=3){
        e[k,l]=0
      }

    }
  }
  rBPS <- binary.segmentation(
    e,
    id = c("NLST", "AA00474", "11030"),
    filter = 150,
    categories = c("geometric", "boundary", "topological")
  )

  #return(rBPS$desc$convexity)            # Convexity
  return(rBPS$desc$eccentricity)         # Eccentricity
  #return(rBPS$desc$total.abs.curvature)  # Total Absolute Curvature
}

## =========================== Set Null images ===============================##

rot=seq(0,360,10)
X=array(0,dim=c(nrow(x),ncol(x),length(rot)))
for(i in 1:length(rot)){
  set.seed(2024+i)
  X[,,i]=rotateImage(x,rot[i] , threads = 1)+matrix(rnorm(nrow(x)*ncol(x),0,0.05),nrow=nrow(x),ncol=ncol(x)) #sigma=0.02
}
image(X[,,2],useRaster=TRUE,axes=FALSE,col=gray(0:256/256),asp=1)

# ================== To find empirical distribution of Test statistic  =================#

library(foreach)
library(doParallel)

#setup parallel backend to use many processors
cores=detectCores()
cl <- makeCluster(cores[1]-1) #not to overload your computer
registerDoParallel(cl)

bb=1000
T_e=foreach(i = 1:bb,.combine = c)%dopar%{

  library(magic)
  library(pracma)
  library(jpeg)
  library(DRIP)
  library(twosamples)
  library(SAFARI)
  set.seed(2024+i)
  img1_star=X[,,sample(1:length(rot),1,replace=T)]
  shape_descriptor_1=shape_descriptor(img1_star,3)[1]
  #shape_descriptor_1
}
cut_off1=quantile(T_e,0.025)
cut_off2=quantile(T_e,0.975)

##==== To calculate empirical size and power ====##

rot=seq(0,360,10)
Y=array(0,dim=c(nrow(x),ncol(x),length(rot)))
for(i in 1:length(rot)){
  set.seed(2024+i)
  Y[,,i]=rotateImage(m1,rot[i] , threads = 1)+matrix(rnorm(nrow(x)*ncol(x),0,0.05),nrow=nrow(x),ncol=ncol(x)) #sigma=0.02
}


# Use "m"  to evaluate the size of the proposed test
# Use "m1"  to evaluate the size of the proposed test

library(foreach)
library(doParallel)

#setup parallel backend to use many processors
cores=detectCores()
cl <- makeCluster(cores[1]-1) #not to overload your computer
registerDoParallel(cl)
#h_n=3 # bandwidth parameter h_n is 2
bb=1000
TT=foreach(i = 1:bb,.combine = c)%dopar%{

  library(magic)
  library(pracma)
  library(jpeg)
  library(DRIP)
  library(twosamples)
  library(SAFARI)
  set.seed(2024+i)

  img2_star=Y[,,sample(1:length(rot),1,replace=T)]
  shape_descriptor_2=shape_descriptor(img2_star,3)[1]
  #shape_descriptor_2
}


count=0
for(i in 1:bb){
  if(TT[i]<cut_off1 | TT[i]> cut_off2){
    count=count+1
  }
}
empirical_power=count/bb
empirical_power
