#==============================================================================#
##================ R-Code For Image  Shape and Size Monitoring (Rstudio: version- 4.3.2)===============##
#==============================================================================#

#Remark : This code will generate the value from Table 3 with kappa=0.1 and g_3_OC [cell no -(3,2)]

# Estimated time to set the IC ARL: 40-50 mins (with 15 cores and 1000 repetitions (i.e.,"bb=1000" in this code))


##============================ Required Libraries ============================##
library(foreach)
library(doParallel)
library(DRIP) # version: 1.8
library(twosamples)
library(OpenImageR) # version: 1.3.0
#==============================================================================#


##================== Function for euclidean distance =========================##
ed=function(vect1, vect2) sqrt(sum((vect1 - vect2)^2))
#==============================================================================#


##===== Function for sample point determination based on radial distance =====##
sample_radial=function(X){
  #X: Image matrix
  #X=readJPEG("2004-1c1.jpg")[,,1]
  est_img=JPLLK_surface(X,3,plot = F)$fitted
  e=stepEdgeLL2K(est_img,3,(qnorm(0.999,0,1)*JPLLK_surface(est_img,3)$sigma),plot = F)
  e[1,]=0
  e[2,]=0
  e[,1]=0
  e[,2]=0
  e[nrow(X),]=0
  e[nrow(X)-1,]=0
  e[,ncol(X)]=0
  e[,ncol(X)-1]=0
  for(k in 1:nrow(X)){
    for(l in 1:ncol(X)){
      if(k>2 && l>2 && k< (nrow(X)-1) && l< (ncol(X)-1) && e[k,l]==1 &&  sum(e[(k-1):(k+1),(l-1):(l+1)])<=4){
        e[k,l]=0
      }
      
    }
  }
  e[1,]=0
  e[2,]=0
  e[,1]=0
  e[,2]=0
  e[nrow(X),]=0
  e[nrow(X)-1,]=0
  e[,ncol(X)]=0
  e[,ncol(X)-1]=0
  for(k in 1:nrow(X)){
    for(l in 1:ncol(X)){
      if(k>2 && l>2 && k< (nrow(X)-1) && l< (ncol(X)-1) && e[k,l]==1 &&  sum(e[(k-1):(k+1),(l-1):(l+1)])<=3){
        e[k,l]=0
      }
      
    }
  }
  e[1,]=0
  e[2,]=0
  e[,1]=0
  e[,2]=0
  e[nrow(X),]=0
  e[nrow(X)-1,]=0
  e[,ncol(X)]=0
  e[,ncol(X)-1]=0
  for(k in 1:nrow(X)){
    for(l in 1:ncol(X)){
      if(k>2 && l>2 && k< (nrow(X)-1) && l< (ncol(X)-1) && e[k,l]==1 &&  sum(e[(k-1):(k+1),(l-1):(l+1)])<=3){
        e[k,l]=0
      }
      
    }
  }
  P=as.matrix(which(e==1,arr.ind = T))
  #plot(P)
  centroid=apply(P,2,mean)
  radial_dist=c()
  for(v in 1:nrow(P)){
    radial_dist[v]=ed(c(P[v,1],P[v,2]),centroid)
  }
  return(radial_dist)
}
#==============================================================================#

## Refernce Image ##
x=matrix(0,128,128,dimnames=list(1:128,1:128))
for(i in 1:128){
  for(j in 1:128){
    if((((i-64)/24)^2+((j-64)/32)^2<1)){
      x[i,j]=1
    }
  }
}
image(x,useRaster=TRUE,axes=FALSE,col=gray(0:256/256),asp=1)

## Null image/ IC image with translation and rotation ##

m=matrix(0,128,128,dimnames=list(1:128,1:128))
for(i in 1:128){
  for(j in 1:128){
    if((((i-60)/32)^2+((j-60)/24)^2<1)){
      m[i,j]=1
    }
  }
}
image(m,useRaster=TRUE,axes=FALSE,col=gray(0:256/256),asp=1)

### Alternative image/ OC image without translation and rotation ##

m1=matrix(0,128,128,dimnames=list(1:128,1:128))
for(i in 1:128){
  for(j in 1:128){
    if((((i-60)/32.5)^2+((j-60)/24)^2<1)){
      m1[i,j]=1
    }
  }
}
image(m1,useRaster=TRUE,axes=FALSE,col=gray(0:256/256),asp=1)

#Remark: Refer to file name "R Code (Simulated Images)- On Shape and Size monitoring of image objects.R" for other simulated images

## =========================== Set of IC images ==============================##
rot=seq(0,360,10)
X=array(0,dim=c(nrow(x),ncol(x),length(rot)))
for(i in 1:length(rot)){
  set.seed(2024+i)
  X[,,i]=rotateImage(x,rot[i] , threads = 1)+matrix(rnorm(nrow(x)*ncol(x),0,0.02),nrow=nrow(x),ncol=ncol(x))
}
image(X[,,2],useRaster=TRUE,axes=FALSE,col=gray(0:256/256),asp=1)
# Remark: x is the reference image 

#==============================================================================#


#=========== Combined estimate of distribution of radial distance =============#
Combined_sample=c()
for(i in 1:length(rot)){
  Combined_sample=append(Combined_sample,  sample_radial(X[,,i]))
}


b=c()
for(k  in 1:length(rot)){
  b[k]=cvm_test(sample_radial(X[,,k]),Combined_sample)[1]
}
E_ic= mean(b)  # IC mean 
sd_ic=sd(b)    # IC sd
#==============================================================================#

# ========================  To set IC-ARL (ARL_0) =20 =========================#
library(foreach)
library(doParallel)

#setup parallel backend to use many processors
cores=detectCores()
cl <- makeCluster(cores[1]-2) #not to overload your computer
registerDoParallel(cl)

bb=1000
count_0=foreach(i = 1:bb,.combine = c)%dopar%{
  
  library(jpeg)
  library(DRIP)
  library(twosamples)
  s=0
  Q_k=0
  set.seed(2024+i)
  while(Q_k<=14.25){
    s=s+1
    if (s <5){
      img=X[,,sample(1:length(rot),1)]
      est_img=JPLLK_surface(img,3)$fitted
    }else{
      img=X[,,sample(1:length(rot),1)]
      est_img=JPLLK_surface(img,3)$fitted
    }
    
    radial_distance=sample_radial(est_img)
    lambda_k=((as.vector(cvm_test(radial_distance,Combined_sample))[1]))
    Q_k=max(0,(Q_k+((lambda_k-E_ic)/sd_ic)-0.5))
    
  }
  s
}

mean(count_0) #approximately mean(count_0) is 20
sd(count_0)
median(count_0)

#Remark: Here 14.25 is the UCL 

#==============================================================================#





## ============================ Set of OC images =============================##

rot=seq(0,360,10)
Y=array(0,dim=c(nrow(m),ncol(m),length(rot)))
for(i in 1:length(rot)){
  set.seed(2024+i)
  Y[,,i]=rotateImage(m1,rot[i] , threads = 1)+matrix(rnorm(nrow(x)*ncol(x),0,0.02),nrow=nrow(x),ncol=ncol(x))
}

for(i in 1:length(rot)){
  sample_radial(Y[,,i])
}
#=============================================================================##


#Remark: #Use "m"  from the simulated images to calculate the ARL_1 with IC images
         #Use "m1" from the simulated images to calculate the ARL_1 with OC images



#========================== To evaluate OC-ARL (ARL_1) ========================#

bb=1000
count_1=foreach(i = 1:bb,.combine = c)%dopar%{
  set.seed(2024+i)
  library(magic)
  library(pracma)
  library(jpeg)
  library(DRIP)
  library(twosamples)
  s=0
  Q_k=0
  while(Q_k<=14.25){
    
    s=s+1
    if (s <5){
      img=X[,,sample(1:length(rot),1)]
      est_img=JPLLK_surface(img,3)$fitted
    }else{
      img=Y[,,sample(1:length(rot),1)]
      est_img=JPLLK_surface(img,3)$fitted
    }
    
    radial_distance=sample_radial(est_img)
    lambda_k=((as.vector(cvm_test(radial_distance,Combined_sample))[1]))
    Q_k=max(0,(Q_k+((lambda_k-E_ic)/sd_ic)-0.5))
    
  }
  s
}

# To compute the ARL under OC images #
mean(count_1[count_1>4]-4)
sd(count_1[count_1>4]-4)
median(count_1[count_1>4]-4)



# To compute the ARL under IC images (named as "m") #
mean(count_1)
sd(count_1)
median(count_1)

#==============================================================================#



