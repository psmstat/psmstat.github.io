#==============================================================================#
### Different Simulated Images for Shape and Size Monitoring of Image Object (Rstudio: version- 4.3.2) ###
#==============================================================================#


##================== Image Resolution: 128 * 128 =============================##

## Refernce Image ##
x=matrix(0,128,128,dimnames=list(1:128,1:128))
for(i in 1:128){
  for(j in 1:128){
    if((((i-64)/24)^2+((j-64)/32)^2<1)){
      x[i,j]=1
    }
  }
}
image(x,useRaster=TRUE,axes=FALSE,col=gray(0:256/256),asp=1)

## Null image/ IC image with translation and rotation ##

m=matrix(0,128,128,dimnames=list(1:128,1:128))
for(i in 1:128){
  for(j in 1:128){
    if((((i-60)/32)^2+((j-60)/24)^2<1)){
      m[i,j]=1
    }
  }
}
image(m,useRaster=TRUE,axes=FALSE,col=gray(0:256/256),asp=1)

## Null image/ IC image with smooth change in the background ##
m=matrix(0,128,128,dimnames=list(1:128,1:128))
for(i in 1:128){
  for(j in 1:128){
    if((((i-60)/32)^2+((j-60)/24)^2<1)){
      m[i,j]=1
    }else{
      m[i,j]=0.1*sin(0.1*(i+j))
    }
    
  }
}
image(m,useRaster=TRUE,axes=FALSE,col=gray(0:256/256),asp=1)

### Alternative image/ OC image without translation and rotation ##

m1=matrix(0,128,128,dimnames=list(1:128,1:128))
for(i in 1:128){
  for(j in 1:128){
    if((((i-60)/32.5)^2+((j-60)/24)^2<1)){
      m1[i,j]=1
    }
  }
}
image(m1,useRaster=TRUE,axes=FALSE,col=gray(0:256/256),asp=1)


### Alternative image/ OC image with translation and rotation ##

m1=matrix(0,128,128,dimnames=list(1:128,1:128))
for(i in 1:128){
  for(j in 1:128){
    if((((i-60)/24.5)^2+((j-60)/32)^2<1)){
      m1[i,j]=1
    }
  }
}
image(m1,useRaster=TRUE,axes=FALSE,col=gray(0:256/256),asp=1)


### Alternative image/ OC image with shape change ##
m1=matrix(0,128,128,dimnames=list(1:128,1:128))
for(i in 1:128){
  for(j in 1:128){
    if((((i-60)/32)^2+((j-60)/24)^2<1)){
      m1[i,j]=1
    }
  }
}
for(i in 1:128){
  for(j in 1:128){
    if(i+j>154){
      m1[i,j]=0
    }
  }
}
image(m1,useRaster=TRUE,axes=FALSE,col=gray(0:256/256),asp=1)


##============================================================================##


##================== Image Resolution: 256 * 256 =============================##

## Refernce Image ##
x=matrix(0,256,256,dimnames=list(1:256,1:256))
for(i in 1:256){
  for(j in 1:256){
    if((((i-128)/48)^2+((j-128)/64)^2<1)){
      x[i,j]=1
    }
  }
}
image(x,useRaster=TRUE,axes=FALSE,col=gray(0:256/256),asp=1)

## Null image/ IC image with translation and rotation ##

m=matrix(0,256,256,dimnames=list(1:256,1:256))
for(i in 1:256){
  for(j in 1:256){
    if((((i-120)/64)^2+((j-120)/48)^2<1)){
      m[i,j]=1
    }
  }
}
image(m,useRaster=TRUE,axes=FALSE,col=gray(0:256/256),asp=1)

## Null image/ IC image with smooth change in the background ##

m=matrix(0,256,256,dimnames=list(1:256,1:256))
for(i in 1:256){
  for(j in 1:256){
    if((((i-120)/64)^2+((j-120)/48)^2<1)){
      m[i,j]=1
    }else{
      m[i,j]=0.1*sin(0.1*(i+j))
    }
    
  }
}
image(m,useRaster=TRUE,axes=FALSE,col=gray(0:256/256),asp=1)


### Alternative image/ OC image without translation and rotation ##

m1=matrix(0,256,256,dimnames=list(1:256,1:256))
for(i in 1:256){
  for(j in 1:256){
    if((((i-120)/65)^2+((j-120)/48)^2<1)){
      m1[i,j]=1
    }
  }
}
image(m1,useRaster=TRUE,axes=FALSE,col=gray(0:256/256),asp=1)


### Alternative image/ OC image with translation and rotation ##

m1=matrix(0,256,256,dimnames=list(1:256,1:256))
for(i in 1:256){
  for(j in 1:256){
    if((((i-120)/49)^2+((j-120)/64)^2<1)){
      m1[i,j]=1
    }
  }
}
image(m1,useRaster=TRUE,axes=FALSE,col=gray(0:256/256),asp=1)


## Alternative image/ OC image with shape change ##

m1=matrix(0,256,256,dimnames=list(1:256,1:256))
for(i in 1:256){
  for(j in 1:256){
    if((((i-120)/64)^2+((j-120)/48)^2<1)){
      m1[i,j]=1
    }
  }
}
for(i in 1:256){
  for(j in 1:256){
    if(i+j>308){
      m1[i,j]=0
    }
  }
}
image(m1,useRaster=TRUE,axes=FALSE,col=gray(0:256/256),asp=1)
