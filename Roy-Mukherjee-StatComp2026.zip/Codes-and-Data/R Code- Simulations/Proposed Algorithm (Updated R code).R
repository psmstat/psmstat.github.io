#==============================================================================#
##================ R-Code For Image  Shape and Size Comparison (Rstudio: version- 4.2.2) ===============##
#==============================================================================#
#Remark : This code will generate the value from Table-3 with nh_n=2 and Star-H_1^(1) [cell no -(2,2)]
#Estimate time to find empirical distribution: 1-2 mins(with 15 cores, bandwidth(h_n)=2, and 1000 replications (i.e., "bb=10000" in R code) )

##============================ Required Libraries ============================##
library(foreach)
library(doParallel)
library(DRIP)   # version: 2.3
library(twosamples)
library(OpenImageR) # version: 1.3.0
#==============================================================================#


##================ True Star Shape Image Object ==========##
x=matrix(0,256,256)
k=0
for(i in 88:168){
  x[(128-k):(128+k),i]=1
  k=k+1
}
for(i in 120:200){
  x[(128-k):(128+k),i]=1
  k=k-1
}

image(x,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))

##========= Star- H_1^(1) ==========##
m1=matrix(0,256,256)
k=0
for(i in 88:168){
  m1[(128-k):(128+k),i]=1
  k=k+1
}
for(i in 120:200){
  m1[(128-k):(128+k),i]=1
  k=k-1
}
for(i in 1:256){
  for(j in 1:256){
    if((i-128)^2+(j-128)^2<33^2){
      m1[i,j]=1
    }
  }
}

image(m1,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))


##================== Function for euclidean distance =========================##
ed=function(vect1, vect2) sqrt(sum((vect1 - vect2)^2))
#==============================================================================#


##===== Function for sample point determination based on radial distance =====##
sample_radial=function(X,h_n){
  #X: Image matrix
  #X=readJPEG("2004-1c1.jpg")[,,1]
  est_img=JPLLK_surface(X,3,plot = F)$fitted
  e=stepEdge(est_img,h_n,(qnorm(0.999,0,1)*JPLLK_surface(est_img,3)$sigma),degree=0,plot = F)
  e[1,]=0
  e[2,]=0
  e[,1]=0
  e[,2]=0
  e[nrow(X),]=0
  e[nrow(X)-1,]=0
  e[,ncol(X)]=0
  e[,ncol(X)-1]=0
  for(k in 1:nrow(X)){
    for(l in 1:ncol(X)){
      if(k>2 && l>2 && k< (nrow(X)-1) && l< (ncol(X)-1) && e[k,l]==1 &&  sum(e[(k-1):(k+1),(l-1):(l+1)])<=4){
        e[k,l]=0
      }

    }
  }
  e[1,]=0
  e[2,]=0
  e[,1]=0
  e[,2]=0
  e[nrow(X),]=0
  e[nrow(X)-1,]=0
  e[,ncol(X)]=0
  e[,ncol(X)-1]=0
  for(k in 1:nrow(X)){
    for(l in 1:ncol(X)){
      if(k>2 && l>2 && k< (nrow(X)-1) && l< (ncol(X)-1) && e[k,l]==1 &&  sum(e[(k-1):(k+1),(l-1):(l+1)])<=3){
        e[k,l]=0
      }

    }
  }
  e[1,]=0
  e[2,]=0
  e[,1]=0
  e[,2]=0
  e[nrow(X),]=0
  e[nrow(X)-1,]=0
  e[,ncol(X)]=0
  e[,ncol(X)-1]=0
  for(k in 1:nrow(X)){
    for(l in 1:ncol(X)){
      if(k>2 && l>2 && k< (nrow(X)-1) && l< (ncol(X)-1) && e[k,l]==1 &&  sum(e[(k-1):(k+1),(l-1):(l+1)])<=3){
        e[k,l]=0
      }

    }
  }
  P=as.matrix(which(e==1,arr.ind = T))
  plot(P)
  centroid=apply(P,2,mean)
  radial_dist=c()
  for(v in 1:nrow(P)){
    radial_dist[v]=ed(c(P[v,1],P[v,2]),centroid)
  }
  return(radial_dist)
}
#==============================================================================#


## =========================== Set Null images ===============================##


rot=seq(0,360,10)
X=array(0,dim=c(nrow(x),ncol(x),length(rot)))
for(i in 1:length(rot)){
  set.seed(2024+i)
  X[,,i]=rotateImage(x,rot[i] , threads = 1)+matrix(rnorm(nrow(x)*ncol(x),0,0.05),nrow=nrow(x),ncol=ncol(x)) #sigma=0.02
}
image(X[,,2],useRaster=TRUE,axes=FALSE,col=gray(0:256/256),asp=1)

#==============================================================================#
radial_distance=sample_radial(X[,,2],2)
hist(radial_distance)
# ================== To find empirical distribution of T_CVM  =================#

library(foreach)
library(doParallel)

#setup parallel backend to use many processors
cores=detectCores()
cl <- makeCluster(cores[1]-2) #not to overload your computer
registerDoParallel(cl)
h_n=2 # bandwidth parameter h_n is 2
bb=1000
T_cvm=foreach(i = 1:bb,.combine = c)%dopar%{

  library(magic)
  library(pracma)
  library(jpeg)
  library(DRIP)
  library(twosamples)
  set.seed(2024+i)
  img1_star=X[,,sample(1:length(rot),1,replace=T)]
  img2_star=x+matrix(rnorm(nrow(x)*ncol(x),0,0.05),nrow=nrow(x),ncol=ncol(x)) #sigma=0.02

  radial_distance_1=sample_radial(img1_star,h_n)
  radial_distance_2=sample_radial(img2_star,h_n)

  as.vector(cvm_test(radial_distance_1,radial_distance_2))[1]

}
cut_off=quantile(T_cvm,0.95)

#============================= To calculate POWER  ============================#
library(foreach)
library(doParallel)

#setup parallel backend to use many processors
cores=detectCores()
cl <- makeCluster(cores[1]-2) #not to overload your computer
registerDoParallel(cl)
h_n=2 # bandwidth parameter h_n is 2
bb=1000
T_cvm=foreach(i = 1:bb,.combine = c)%dopar%{

  library(magic)
  library(pracma)
  library(jpeg)
  library(DRIP)
  library(twosamples)
  set.seed(2024+i)
  img1_star=X[,,sample(1:length(rot),1,replace=T)]
  img2_star=m1+matrix(rnorm(nrow(x)*ncol(x),0,0.05),nrow=nrow(x),ncol=ncol(x)) #sigma=0.02

  # Use "m"  to evaluate the size of the proposed test
  # Use "m1"  to evaluate the size of the proposed test

  radial_distance_1=sample_radial(img1_star,h_n)
  radial_distance_2=sample_radial(img2_star,h_n)

  as.vector(cvm_test(radial_distance_1,radial_distance_2))[1]

}
power=sum(T_cvm>cut_off)/bb
power
