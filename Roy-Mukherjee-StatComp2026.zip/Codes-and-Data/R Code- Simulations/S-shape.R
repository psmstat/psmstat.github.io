##-- Generating S-shape --##


##-- Function to generate a 256*256 S-shape --#

make_S <- function(scale = 0.55, nx = 256, ny = 256) {
  base_r <- 1
  r <- base_r * scale
  
  xlim <- c(-1.25*base_r,  1.25*base_r)
  ylim <- c(-2.25*base_r,  2.25*base_r)
  
  # stroke half-thickness in world units (tweak if needed)
  eps <- 0.025 * r
  
  xs <- seq(xlim[1], xlim[2], length.out = nx)
  ys <- seq(ylim[1], ylim[2], length.out = ny)
  
  # mesh in pixel coords (rows=y, cols=x)
  Xw <- matrix(rep(xs, each = ny), nrow = ny, ncol = nx)
  Yw <- matrix(rep(ys, times = nx),  nrow = ny, ncol = nx)
  
  d_top <- abs(sqrt((Xw)^2 + (Yw -  r)^2) - r)
  d_bot <- abs(sqrt((Xw)^2 + (Yw +  r)^2) - r)
  
  mask <- (Xw >= 0 & d_top <= eps) | (Xw <= 0 & d_bot <= eps)
  matrix(as.integer(mask), nrow = ny, ncol = nx)
}
## -------- 2) Bilinear sampler over arbitrary (x,y) -------------------
bilinear_sample <- function(Im, x, y) {
  ny <- nrow(Im); nx <- ncol(Im)
  # clamp coords to [1,n]
  x <- pmin(pmax(x, 1), nx); y <- pmin(pmax(y, 1), ny)
  
  x0 <- floor(x); y0 <- floor(y)
  x1 <- pmin(x0 + 1, nx); y1 <- pmin(y0 + 1, ny)
  dx <- x - x0; dy <- y - y0
  
  Ia <- Im[cbind(y0, x0)]
  Ib <- Im[cbind(y0, x1)]
  Ic <- Im[cbind(y1, x0)]
  Id <- Im[cbind(y1, x1)]
  
  (1 - dx) * (1 - dy) * Ia +
    dx     * (1 - dy) * Ib +
    (1 - dx) * dy     * Ic +
    dx       * dy     * Id
}

## -------- 3) Local Gaussian radial deformation -----------------------
# amp  > 0  = push outward from center (bulge)
# amp  < 0  = pull inward toward center (dent)
# sigma     = spatial spread (pixels)
deform_local_radial <- function(Im, cx, cy, amp = -12, sigma = 18) {
  ny <- nrow(Im); nx <- ncol(Im)
  # pixel grids (rows = y, cols = x)
  X <- matrix(rep(1:nx, each = ny), nrow = ny, ncol = nx)
  Y <- matrix(rep(1:ny, times = nx), nrow = ny, ncol = nx)
  
  dx <- X - cx
  dy <- Y - cy
  r2 <- dx*dx + dy*dy
  r  <- sqrt(r2) + 1e-6
  
  w  <- exp(-r2 / (2 * sigma^2))      # Gaussian falloff
  ux <- amp * w * dx / r              # radial displacement x
  uy <- amp * w * dy / r              # radial displacement y
  
  # inverse mapping: sample source at (x - u, y - v)
  Xs <- X - ux
  Ys <- Y - uy
  
  vals <- bilinear_sample(Im, as.vector(Xs), as.vector(Ys))
  M <- matrix(vals, nrow = ny, ncol = nx)
  
  # back to binary
  ifelse(M > 0.5, 1L, 0L)
}

## -- IC & OC image Generation --##

#set.seed(1)
S  <- make_S(scale = 0.65) 
S1  <- make_S(scale = 0.7) 
S2 <- deform_local_radial(S, cx = 155, cy = 150, amp = +7, sigma = 40)  # local dent
S3 <- deform_local_radial(S, cx = 155, cy = 150, amp = -7, sigma = 40)  # local dent

# quick plot helpers (keep orientation intuitive)
plot_bin <- function(M, main = "") {
  image(t(M)[, nrow(M):1], col = c("white","black"),
        axes = FALSE, xlab = "", ylab = "", useRaster = TRUE, main = main)
  box()
}

par(mfrow=c(1,4))
image(S)
image(S1)
image(S2)
image(S3)