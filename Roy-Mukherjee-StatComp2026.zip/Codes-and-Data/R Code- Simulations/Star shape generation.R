
###==========================================###
###====== Varrious Star-Shaped Images =======###
###==========================================###


##================ True Star Shape Image Object ==========##
x=matrix(0,256,256)
k=0
for(i in 88:168){
  x[(128-k):(128+k),i]=1
  k=k+1
}
for(i in 120:200){
  x[(128-k):(128+k),i]=1
  k=k-1
}

image(x,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))



##============ Star- H_0 ===========##

library(OpenImageR)
m=rotateImage(x,45 , threads = 1)
image(m,col=gray(0:256/256))

##========= Star- H_1^(1) ==========##
m1=matrix(0,256,256)
k=0
for(i in 88:168){
  m1[(128-k):(128+k),i]=1
  k=k+1
}
for(i in 120:200){
  m1[(128-k):(128+k),i]=1
  k=k-1
}
for(i in 1:256){
  for(j in 1:256){
    if((i-128)^2+(j-128)^2<33^2){
      m1[i,j]=1
    }
  }
}

image(m1,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))

##========= Star- H_1^(2) ==========##

m1=matrix(0,256,256)
k=0
for(i in 88:168){
  m1[(128-k):(128+k),i]=1
  k=k+1
}
for(i in 120:200){
  m1[(128-k):(128+k),i]=1
  k=k-1
}
for(i in 1:256){
  for(j in 1:256){
    if((i-138)^2+(j-149)^2<39.5^2){
      m1[i,j]=1
    }
  }
}
image(m1,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))


##========= Star- H_1^(3) ==========##
m1=matrix(0,256,256)
k=0
for(i in 88:168){
  m1[(120-k):(128+k),i]=1
  k=k+1
}
for(i in 120:200){
  m1[(128-k):(128+k),i]=1
  k=k-1
}

image(m1,useRaster=TRUE,axes=FALSE,col = gray(0:256 / 256))

