LOOCV=function(nimg,bandwidth){
  alpha=0.001
  h=bandwidth
  pad_length=6
  pad_img=function(img,pad_length){
    library(magic)
    img1=apad(img,c(pad_length,pad_length),method="mirror")
    img2=rbind(img1[pad_length:1,],img1)
    img_final=cbind(img2[,pad_length:1],img2)
    return(img_final)
  }
  M=pad_img(nimg,pad_length)
  
  # Local Linear kernel estimate #
  b0_hat=matrix(0,nrow=nrow(M),ncol=ncol(M))#matrix to store the slope for each pixel
  r00=matrix(0,nrow=nrow(M),ncol=ncol(M))
  cv=matrix(0,nrow=nrow(M),ncol=ncol(M))
  for(i in (1+ceiling(h)):(nrow(M)-ceiling(h))){
    for(j in (1+ceiling(h)):(ncol(M)-ceiling(h))){
      
      bst_1=0
      mst_1=0
      
      for(k in (i-ceiling(h)):(i+ceiling(h))){
        for(l in (j-ceiling(h)):(j+ceiling(h))){
          bst_1=bst_1+{M[k,l]*(k-i)^0*(l-j)^0*(2/(pi))*(1-((k-i)/h)^2-((l-j)/h)^2)*
              as.numeric(I(((k-i)/h)^2+((l-j)/h)^2<=1))}
          mst_1=mst_1+{(2/(pi))*(1-((k-i)/h)^2-((l-j)/h)^2)*
              as.numeric(I(((k-i)/h)^2+((l-j)/h)^2<=1))}
          
        }
      }
      b0_hat[i,j]=(bst_1/mst_1)
      r00[i,j]=(2/pi)*(1/mst_1)
      cv[i,j]=((M[i,j]-b0_hat[i,j])/(1-r00[i,j]))^2
    }
  }
  
  CV=cv[(pad_length+1):(nrow(M)-pad_length),(pad_length+1):(nrow(M)-pad_length)]
  return(sum(CV))
}


set.seed(2024)
library(foreach)
library(doParallel)

#setup parallel backend to use many processors
cores=detectCores()
cl <- makeCluster(cores[1]-2) #not to overload your computer
registerDoParallel(cl)

b_width=seq(2,6,by=0.5)
mean_cvscore=c()

for(k in 1:length(b_width)){
  b=25 #Number of replications for calculating EMSE
  cvscore=foreach(i = 1:b,.combine = c)%dopar%{
    library(magic)
    library(pracma)
    #library(jpeg)
    library(DRIP)
    set.seed(2024+i)
    image=x+matrix(rnorm(nrow(x)*ncol(x),0,0.05),nrow=nrow(x),ncol=ncol(x))
    LOOCV(image,b_width[k])
  }
  mean_cvscore[k]=mean(cvscore)
  
}


##=========================== Plot of the CV Score ============================#
data=data.frame(cbind(b_width,mean_cvscore))
library(ggplot2)
ggplot(data)+aes(x = b_width, y = mean_cvscore)+geom_line()+geom_point()+xlim(2,6)+ylim(50,250)+labs(title =  expression(paste('                    ',n,'=256',',', ' ', sigma,'=0.02')),
                                                                                                           x= expression(paste( n*h[n])),
                                                                                                           y = "CV score",
                                                                                                           size=15)+theme(axis.text=element_text(size=14),
#==============================================================================# 