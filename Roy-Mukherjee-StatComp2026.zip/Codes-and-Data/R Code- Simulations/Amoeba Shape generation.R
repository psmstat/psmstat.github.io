###==========================================###
###====== Varrious Amoeba-Shaped Images =======###
###==========================================###


##================ True Amoeba-Shaped Image Object ==========##
g= function(f,scale,mode=1)
{
  if(mode == 1)  h= function(x) f(x)
  if(mode ==2)  h= function(x) return(((f(x)*f(2*pi-x))^2)^0.25)
  img= array(1,dim=c(256,256))
  for(i in 1:256)
    for(j in 1:256)
    {
      loc1=i-128
      loc2=j-128
      rat=loc2/loc1
      if(loc2==0) rat=0
      theta= atan(rat)
      if(loc2*theta < 0) theta = theta +pi
      if(theta ==0 & loc1 <0) theta =pi
      if(theta < 0) theta = 2*pi + theta
      val = 1+h(theta)
      dist = (loc1^2+loc2^2)^0.5
      if(val*scale<dist)
        img[i,j]=0
    }
  return(img)

}
a=g(function(x) (sin(5*x)/4),50)
x=a
image(a,col=gray(0:256/256))





##============ Amoeba- H_0 ===========##
library(OpenImageR)
m=rotateImage(x,45 , threads = 1)
image(m,col=gray(0:256/256))


##========= Amoeba- H_1^(1) ==========##

m1=g(function(x) ((sin(4.85*x))/4),50)
image(m1,col=gray(0:256/256))


##========= Amoeba- H_1^(2) ==========##

m1=g(function(x) ((sin(5*x))/4),52.5)
image(m1,col=gray(0:256/256))


##========= Amoeba- H_1^(3) ==========##

m1=g(function(x) ((sin(5*x))/4.25),50)
image(m1,col=gray(0:256/256))

m1=g(function(x) ((sin(5*x))/4),52.5)
image(m1,col=gray(0:256/256))

m1=g(function(x) ((sin(5*x))/4.25),50)
image(m1,col=gray(0:256/256))
