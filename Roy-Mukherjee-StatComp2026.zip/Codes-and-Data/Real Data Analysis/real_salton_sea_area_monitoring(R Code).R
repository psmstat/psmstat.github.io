
##========================= Required Library =================================##
library(magic)
library(pracma)
library(jpeg)
library(DRIP)
library(twosamples)
library(foreach)
library(doParallel)

#==============================================================================#

##==================== Function for euclidean distance =======================##
ed=function(vect1, vect2) sqrt(sum((vect1 - vect2)^2))

#==============================================================================#

##===== Function for sample point determination based on radial distance =====##
sample_radial=function(X){
  #X: Image matrix
  #X=readJPEG("2004-1c1.jpg")[,,1]
  est_img=JPLLK_surface(X,3,plot = F)$fitted
  e=stepEdgeLL2K(est_img,3,0.1,plot = F)
  e[1,]=0
  e[2,]=0
  e[,1]=0
  e[,2]=0
  e[nrow(X),]=0
  e[nrow(X)-1,]=0
  e[,ncol(X)]=0
  e[,ncol(X)-1]=0
  for(k in 1:nrow(X)){
    for(l in 1:ncol(X)){
      if(k>2 && l>2 && k< (nrow(X)-1) && l< (ncol(X)-1) && e[k,l]==1 &&  sum(e[(k-1):(k+1),(l-1):(l+1)])<=4){
        e[k,l]=0
      }
      
    }
  }
  e[1,]=0
  e[2,]=0
  e[,1]=0
  e[,2]=0
  e[nrow(X),]=0
  e[nrow(X)-1,]=0
  e[,ncol(X)]=0
  e[,ncol(X)-1]=0
  for(k in 1:nrow(X)){
    for(l in 1:ncol(X)){
      if(k>2 && l>2 && k< (nrow(X)-1) && l< (ncol(X)-1) && e[k,l]==1 &&  sum(e[(k-1):(k+1),(l-1):(l+1)])<=2){
        e[k,l]=0
      }
      
    }
  }
  P=as.matrix(which(e==1,arr.ind = T))
  plot(P)
  centroid=apply(P,2,mean)
  radial_dist=c()
  for(v in 1:nrow(P)){
    radial_dist[v]=ed(c(P[v,1],P[v,2]),centroid)
  }
  return(radial_dist)
}
#==============================================================================#


##=========================== Reading Images =================================##
 

X=array(0,dim=c(236,236,30))                  # Array to store real-TRAIN Images

X[,,1]=readJPEG(file.choose())[,,1]
X[,,2]=readJPEG(file.choose())[,,1]
X[,,3]=readJPEG(file.choose())[,,1]
X[,,4]=readJPEG(file.choose())[,,1]
X[,,5]=readJPEG(file.choose())[,,1]
X[,,6]=readJPEG(file.choose())[,,1]
X[,,7]=readJPEG(file.choose())[,,1]
X[,,8]=readJPEG(file.choose())[,,1]
X[,,9]=readJPEG(file.choose())[,,1]
X[,,10]=readJPEG(file.choose())[,,1]
X[,,11]=readJPEG(file.choose())[,,1]
X[,,12]=readJPEG(file.choose())[,,1]
X[,,13]=readJPEG(file.choose())[,,1]
X[,,14]=readJPEG(file.choose())[,,1]
X[,,15]=readJPEG(file.choose())[,,1]
X[,,16]=readJPEG(file.choose())[,,1]
X[,,17]=readJPEG(file.choose())[,,1]
X[,,18]=readJPEG(file.choose())[,,1]
X[,,19]=readJPEG(file.choose())[,,1]
X[,,20]=readJPEG(file.choose())[,,1]
X[,,21]=readJPEG(file.choose())[,,1]
X[,,22]=readJPEG(file.choose())[,,1]
X[,,23]=readJPEG(file.choose())[,,1]
X[,,24]=readJPEG(file.choose())[,,1]
X[,,25]=readJPEG(file.choose())[,,1]
X[,,26]=readJPEG(file.choose())[,,1]
X[,,27]=readJPEG(file.choose())[,,1]
X[,,28]=readJPEG(file.choose())[,,1]
X[,,29]=readJPEG(file.choose())[,,1]
X[,,30]=readJPEG(file.choose())[,,1]


M=array(0,dim=c(236,236,10))                   # Array to store real-TEST Images
M[,,1]=readJPEG(file.choose())[,,1]
M[,,2]=readJPEG(file.choose())[,,1]
M[,,3]=readJPEG(file.choose())[,,1]
M[,,4]=readJPEG(file.choose())[,,1]
M[,,5]=readJPEG(file.choose())[,,1]
M[,,6]=readJPEG(file.choose())[,,1]
M[,,7]=readJPEG(file.choose())[,,1]
M[,,8]=readJPEG(file.choose())[,,1]
M[,,9]=readJPEG(file.choose())[,,1]
M[,,10]=readJPEG(file.choose())[,,1]


#==============================================================================#

Combined_sample=c()
for(i in 1:30){
  Combined_sample=append(Combined_sample,  sample_radial(X[,,i]))
}


b=c()
for(k  in 1:30){
  b[k]=cvm_test(sample_radial(X[,,k]),Combined_sample)[1]
}

E_ic= mean(b)
sd_ic=sd(b)  

#==============================================================================#

#=========== Setup parallel backend to use many processors ====================#
cores=detectCores()
cl <- makeCluster(cores[1]-2) #not to overload your computer
registerDoParallel(cl)

#==============================================================================#



##======================= To set IC ARL = 20 =================================##
bb=500
count_0=foreach(i = 1:bb,.combine = c)%dopar%{
  
  library(magic)
  library(pracma)
  library(jpeg)
  library(DRIP)
  library(twosamples)
  s=0
  Q_k=0
  set.seed(2024+i)
  while(Q_k<=7.75){
    s=s+1
    if (s <5){
      img=X[,,sample(1:30,1)]
      est_img=JPLLK_surface(img,3)$fitted
    }else{
      img=X[,,sample(1:30,1)]
      est_img=JPLLK_surface(img,3)$fitted
    }
    
    radial_distance=sample_radial(est_img)
    lambda_k=((as.vector(cvm_test(radial_distance,Combined_sample))[1]))
    Q_k=max(0,(Q_k+((lambda_k-E_ic)/sd_ic)-0.1))
    
  }
  s
}

mean(count_0)
sd(count_0)
median(count_0)
#==============================================================================#

#============================= To compute OC- ARL =============================#
bb=500
count_1=foreach(i = 1:bb,.combine = c)%dopar%{
  set.seed(2024+i)
  library(magic)
  library(pracma)
  library(jpeg)
  library(DRIP)
  library(twosamples)
  s=0
  Q_k=0
  while(Q_k<=7.75){
    
    s=s+1
    if (s <5){
      img=X[,,sample(1:30,1)]
      est_img=JPLLK_surface(img,3)$fitted
    }else{
      img=M[,,s-4]
      est_img=JPLLK_surface(img,3)$fitted
    }
    
    radial_distance=sample_radial(est_img)
    lambda_k=((as.vector(cvm_test(radial_distance,Combined_sample))[1]))
    Q_k=max(0,(Q_k+((lambda_k-E_ic)/sd_ic)-0.1)) #allowance parameter is 0.1
    
  }
  s
}
mean(count_1[count_1>4]-4)   # mean OC ARL
sd(count_1[count_1>4]-4)     # standard deviation of OC ARL
median(count_1[count_1>4]-4) # median OC ARL

#==============================================================================#